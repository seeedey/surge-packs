#version 330

// Vanilla 1.21.11 rendertype_item_entity_translucent_cull.vsh + Raysphere additions.
// Everything above the "Raysphere" block is byte-for-byte the stock behaviour, so
// ordinary dropped items / item frames / item displays render exactly as before.

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

// ---------------------------------------------------------------- Raysphere --
// rsPos    : vertex position relative to the camera, in world orientation.
//            (Minecraft bakes the entity pose into the vertices on the CPU, so
//             ModelViewMat is purely the camera matrix and Position is already
//             camera-relative world space -- vanilla relies on this for fog.)
// rsLocal  : where this vertex sits inside its quad, as (0,0)/(1,0)/(1,1)/(0,1).
//            Derived from gl_VertexID because Minecraft draws every quad as four
//            consecutive vertices through the shared quad index buffer. This is
//            what lets the fragment shader recover the quad -- and therefore the
//            cube, and therefore the sphere centre -- without any encoded texture
//            data, so it is immune to nearest-neighbour filtering and mipmapping.
// rsProjZW : the z and w rows of ProjMat that matter, so the fragment shader can
//            project its own hit point without pulling in the Projection UBO --
//            vanilla's item fragment shader does not declare it, and there is no
//            need to find out the hard way whether adding it upsets pipeline
//            validation. Minecraft's perspective matrix has no x/y coupling in
//            those rows, so two coefficients per row is exact.
// No light directions or lightmap are passed: the orb is emissive and shaded
// purely on view angle, so it glows in the dark instead of going black in a cave.
out vec3      rsPos;
out vec2      rsLocal;
flat out vec4 rsTint;
flat out vec4 rsProjZW;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vec4 lightMap = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * lightMap;
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;

    // ------------------------------------------------------------ Raysphere --
    int corner = gl_VertexID & 3;
    rsLocal    = vec2(float(((corner + 1) >> 1) & 1), float(corner >> 1));
    rsPos      = Position;
    rsTint     = Color;
    rsProjZW   = vec4(ProjMat[2][2], ProjMat[3][2], ProjMat[2][3], ProjMat[3][3]);
}
