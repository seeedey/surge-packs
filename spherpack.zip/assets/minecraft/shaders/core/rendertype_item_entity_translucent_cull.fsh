#version 330

// Vanilla 1.21.11 rendertype_item_entity_translucent_cull.fsh + Raysphere.
//
// How it works
// ------------
// The item model is a 16x16x16 cube whose faces all use one flat marker colour
// (magenta, alpha 254, style id in the green channel). When a fragment's texel
// matches that marker we know we are on the marker cube, so instead of shading
// the cube we:
//
//   1. rebuild the quad's two world-space edge vectors T and B from screen-space
//      derivatives of rsPos against rsLocal,
//   2. from those, rebuild the cube's centre and edge length,
//   3. intersect the eye ray with the sphere inscribed in that cube,
//   4. shade the hit point as a glowing orb, or -- when the ray misses -- as the
//      orb's outer glow, and write gl_FragDepth so it sorts against the world.
//
// The result is a mathematically exact sphere: perfectly smooth at any distance,
// no polygon budget, correct silhouette and depth. Only front faces are drawn and
// the visible faces of a convex solid exactly tile its silhouette, so the sphere
// and its halo are always fully covered by the cube they live in.
//
// The orb shading here is kept in sync by hand with the Iris version in
// shaderpack_raysphere/shaders/lib/raysphere.glsl. Edit both.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

// To animate the plasma and corona styles you need a clock. The only one on
// offer is GameTime in the Globals UBO -- which this pipeline does not declare,
// so adding it may fail shader linking outright and take the whole pack with it.
// No vanilla item/entity shader imports globals.glsl. If you want to try it:
// uncomment the import below and set RS_ANIMATE to 1.
//#moj_import <minecraft:globals.glsl>
#define RS_ANIMATE 0

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

in vec3      rsPos;
in vec2      rsLocal;
flat in vec4 rsTint;
flat in vec4 rsProjZW;

out vec4 fragColor;

// Marker colour. A flat colour survives Minecraft's per-sprite mipmap generation
// bit-exactly, and alpha 254 does not occur in any vanilla item texture, so
// nothing else can trip this branch. Green carries the style id, small enough to
// stay inside the tolerance.
const vec3  RS_MARKER_RGB = vec3(1.0, 0.0, 1.0);
const float RS_MARKER_A   = 254.0 / 255.0;

const int RS_STYLE_CORE   = 0;   // clean glowing marble
const int RS_STYLE_PLASMA = 1;   // swirling energy bands
const int RS_STYLE_CORONA = 2;   // blazing centre, flaring rim
const int RS_STYLE_BEAM   = 3;   // vertical shaft of light
const int RS_STYLE_EYE    = 4;   // eyeball that watches the viewer

// Sphere diameter as a fraction of the cube edge. Well under 1.0 because the
// glow halo has to fit inside the same cube: the halo reaches RS_HALO radii, and
// the cube's silhouette is never closer than 1/RS_FILL radii from the centre.
const float RS_FILL = 0.60;
const float RS_HALO = 1.55;

// Beam: glow radius as a fraction of the box half-width, and the height at which
// the top fade starts (0 = bottom of the box, 1 = top).
const float RS_BEAM_FILL = 0.95;
const float RS_BEAM_FADE = 0.30;

// Faintest fragment still drawn. This is the knob for the water artefact: this
// render type writes depth even for translucent fragments (its pipeline sets
// COLOR_DEPTH_WRITE, and since 1.21.5 pipeline state is hardcoded in Java and
// cannot be overridden by a pack), and Minecraft draws water AFTER entities -- so
// wherever the glow writes depth, the water behind it fails the depth test and
// vanishes. Discarding the faintest fringe shrinks the region that can do that,
// at the cost of a slightly tighter glow. Raise it if the artefact bothers you
// more than the reach of the halo does.
const float RS_MIN_ALPHA = 0.05;

// rsPos is camera-relative WORLD space, so world up is simply +Y.
const vec3 RS_UP = vec3(0.0, 1.0, 0.0);

// Set to 1 to paint the marker cube solid green instead of raytracing it. Useful
// for checking that the item actually reaches this shader at all.
#define RS_DEBUG 0

// Green is NOT tested against the marker colour -- it carries the style id, so it
// only has to stay below 16/255. That caps the design at 16 styles; widen this
// and RS_MARKER_RGB's green if you ever need more.
bool rs_is_marker(vec4 texel) {
    return abs(texel.r - RS_MARKER_RGB.r) < 0.01
        && abs(texel.b - RS_MARKER_RGB.b) < 0.01
        && texel.g < 0.0627
        && abs(texel.a - RS_MARKER_A) < 0.003;
}

// Ray versus a vertical shaft of light. Rather than intersecting a solid
// cylinder, this finds how close the eye ray passes to the beam's axis and turns
// that into a radial falloff -- soft edges for free, and it reads as volumetric
// rather than as a lit tube.
//
// Returns false when there is nothing to draw.
bool rs_beam(vec3 eye, vec3 T, vec3 B, vec3 faceCentre, vec3 outward, vec3 up,
             vec3 tint, out vec3 shaded, out float alpha, out vec3 depthPoint) {
    // The axis is the LONGER edge of this quad -- a beam is by definition taller
    // than it is wide. Deriving it from the geometry rather than assuming world up
    // is what lets a beam be rotated to any angle; world up is then used only to
    // decide which end the glow fades toward.
    //
    // This is also why beams support non-uniform scale and orbs do not: knowing
    // which edge is the axis pins down the third extent, which one quad of a
    // general box otherwise cannot give you.
    float lt = length(T);
    float lb = length(B);
    if (max(lt, lb) < 1.5 * min(lt, lb)) {
        return false;                       // too square to identify the axis
    }
    vec3 axisEdge  = (lt > lb) ? T : B;
    vec3 crossEdge = (lt > lb) ? B : T;

    float halfW = 0.5 * length(crossEdge);
    float halfH = 0.5 * length(axisEdge);

    vec3 u = normalize(axisEdge);

    // Orienting the axis so the fade can run base -> tip needs a reference, and
    // world up is the natural one. But it degenerates the moment the beam is
    // horizontal: dot(u, up) ~ 0, the box's four side faces do not agree on which
    // way their own edge vector points, and float noise then flips them
    // independently, splitting the beam into mismatched halves. That was the
    // pitch-90 glitch.
    //
    // verticality is taken from the ABSOLUTE dot, so every face agrees on it no
    // matter which way its edge happens to point. It decides how much to trust a
    // directional fade at all; see the fade blend further down.
    float verticality = abs(dot(u, up));
    if (dot(u, up) < 0.0) {
        u = -u;                             // only meaningful when clearly upright
    }

    // The box is square in cross-section, so stepping inward from the face centre
    // by half the cross edge lands exactly on the axis.
    vec3  axisPoint = faceCentre - outward * halfW;
    float radius    = halfW * RS_BEAM_FILL;

    // Closest approach between the eye ray (origin at the camera) and the axis.
    vec3  w0 = -axisPoint;
    float b  = dot(eye, u);
    float d0 = dot(eye, w0);
    float e0 = dot(u, w0);
    float denom = 1.0 - b * b;

    float s;
    if (denom < 1e-6) {
        s = 0.0;                            // looking straight down the beam
    } else {
        s = (e0 - b * d0) / denom;
    }
    s = clamp(s, -halfH, halfH);

    // Re-project after clamping: for the unclamped case this is the same point,
    // and for the clamped case it correctly gives distance to the segment end.
    vec3  axisPos = axisPoint + u * s;
    float t = dot(axisPos, eye);
    if (t <= 0.0) {
        return false;
    }
    vec3  rayPos = eye * t;
    float dist   = length(rayPos - axisPos);

    float f = clamp(1.0 - dist / radius, 0.0, 1.0);
    if (f <= 0.0) {
        return false;
    }
    float core = pow(f, 2.5);               // tight bright core
    float haze = pow(f, 0.8) * 0.35;        // wide soft halo

    // Directional fade runs base -> tip, so an upright beam dissolves into the
    // sky. Symmetric fade tapers from the middle toward both ends -- it depends
    // only on |s|, so it cannot disagree between faces the way a directional fade
    // does, and a horizontal beam reads as a deliberate bar of light rather than
    // as a beam fading the wrong way.
    //
    // Blending on verticality means the directional term is only trusted where
    // dot(u, up) is decisive enough for the sign flip above to be stable, and the
    // blend weight itself is sign-independent, so there is no knife edge.
    float hDir = (s + halfH) / (2.0 * halfH);            // 0 base   -> 1 tip
    float hSym = abs(s) / halfH;                         // 0 centre -> 1 either end
    float height = mix(hSym, hDir, smoothstep(0.25, 0.55, verticality));
    float fade   = 1.0 - smoothstep(RS_BEAM_FADE, 1.0, height);

    float intensity = (core + haze) * fade;
    if (intensity < RS_MIN_ALPHA) {
        return false;
    }

    shaded     = tint * (0.55 + 1.5 * core) + vec3(1.0) * pow(core, 3.0) * 0.75;
    alpha      = clamp(intensity, 0.0, 1.0);
    depthPoint = rayPos;
    return true;
}

// nrm  : surface normal
// ndv  : how square-on the surface faces the camera, 0..1
// gaze : unit vector from the sphere's centre toward the camera
vec3 rs_orb_colour(int style, vec3 tint, vec3 nrm, float ndv, vec3 gaze, float time) {
    float rim  = pow(1.0 - ndv, 3.0);
    float body = 0.30 + 0.85 * pow(ndv, 1.4);
    vec3 col;

    if (style == RS_STYLE_PLASMA) {
        float a = sin(nrm.y * 7.0 + time * 1.7)
                + sin(nrm.x * 5.0 - nrm.z * 4.0 - time * 2.3)
                + sin(dot(nrm, vec3(3.5, -2.5, 4.5)) + time * 1.1);
        float energy = 0.5 + 0.5 * (a / 3.0);
        energy *= energy;
        col  = tint * body * (0.25 + 1.6 * energy);
        col += tint * rim * 2.0;
        col += vec3(1.0) * pow(energy, 6.0) * 0.55;      // white-hot filaments
    } else if (style == RS_STYLE_CORONA) {
        float flare = 0.5 + 0.5 * sin(atan(nrm.z, nrm.x) * 9.0 + nrm.y * 3.0 + time * 3.0);
        col  = tint * body * 1.15;
        col += tint * (rim * 1.5 + flare * pow(1.0 - ndv, 1.6) * 1.3);
        col += vec3(1.0, 0.95, 0.82) * pow(ndv, 10.0) * 1.15;   // blazing centre
    } else if (style == RS_STYLE_EYE) {
        // ndv is 1 at the point of the sphere facing the camera, so keying the
        // iris off it makes the eye look straight at whoever is looking at it --
        // for every player at once, and with no server-side aiming. There is no
        // gaze to store anywhere; it is a property of who is doing the viewing.
        float ang = acos(clamp(ndv, -1.0, 1.0));    // 0 at the pupil, ~pi/2 at the rim

        // A basis around the gaze, so the iris detail stays anchored to the pupil
        // instead of sliding over the surface as the pupil tracks you. World up
        // keeps the eye upright; it only degenerates looking straight down the
        // gaze axis from above, where the fallback is arbitrary but harmless.
        vec3 gx = cross(vec3(0.0, 1.0, 0.0), gaze);
        float gxl = length(gx);
        gx = (gxl > 0.001) ? gx / gxl : vec3(1.0, 0.0, 0.0);
        vec3 gy = cross(gaze, gx);
        float azim = atan(dot(nrm, gy), dot(nrm, gx));

        float pupil = 0.30 + 0.045 * sin(time * 0.7);           // slow dilation
        float iris  = 0.62;

        // sclera, with veins creeping in from the rim
        float vein = pow(smoothstep(iris, 1.45, ang), 1.5)
                   * (0.5 + 0.5 * sin(azim * 7.0 + sin(azim * 3.0) * 2.0));
        col = vec3(0.90, 0.88, 0.86) - vein * vec3(0.0, 0.30, 0.32);

        // iris: radial fibres, darkening toward the limbus
        float fibre = 0.5 + 0.5 * sin(azim * 34.0 + sin(azim * 11.0) * 1.5);
        float rad   = clamp(ang / iris, 0.0, 1.0);
        vec3 irisCol = tint * (0.35 + 0.75 * fibre * rad) * (1.25 - 0.55 * rad);
        col = mix(irisCol, col, smoothstep(iris - 0.05, iris + 0.02, ang));

        col *= 1.0 - 0.65 * exp(-pow((ang - iris) / 0.055, 2.0));   // limbal ring
        col = mix(vec3(0.015), col, smoothstep(pupil - 0.04, pupil, ang));

        // catchlight, up and off to one side of the gaze
        vec3 hl = normalize(gaze + gy * 0.55 - gx * 0.35);
        col += vec3(1.0) * pow(max(0.0, dot(nrm, hl)), 220.0) * 1.4;
    } else {
        col  = tint * body;
        col += tint * rim * 1.7;
        col += vec3(1.0) * pow(ndv, 20.0) * 0.65;
    }
    return col;
}

void main() {
    vec4 texel = texture(Sampler0, texCoord0);

    // Derivatives have to be taken in uniform control flow, so they are computed
    // before the marker test. They cost a handful of ALU ops on ordinary items.
    vec3 dPdx = dFdx(rsPos);
    vec3 dPdy = dFdy(rsPos);
    vec2 dLdx = dFdx(rsLocal);
    vec2 dLdy = dFdy(rsLocal);

    if (rs_is_marker(texel)) {
#if RS_DEBUG
        gl_FragDepth = gl_FragCoord.z;
        fragColor = vec4(0.0, 1.0, 0.0, 1.0);
        return;
#endif
#if RS_ANIMATE
        float rsTime = GameTime * 1200.0;   // GameTime is 0..1 over 24000 ticks
#else
        float rsTime = 0.0;
#endif
        int style = int(texel.g * 255.0 + 0.5);

        float det = dLdx.x * dLdy.y - dLdx.y * dLdy.x;
        if (abs(det) < 1e-24) {
            discard;
        }

        // World-space edge vectors of this quad, one unit of rsLocal each.
        vec3 T = (dPdx * dLdy.y - dPdy * dLdx.y) / det;
        vec3 B = (dPdy * dLdx.x - dPdx * dLdy.x) / det;

        vec3 faceCentre = rsPos - T * (rsLocal.x - 0.5) - B * (rsLocal.y - 0.5);

        vec3 eye = normalize(rsPos);              // camera -> fragment
        vec3 outward = normalize(cross(T, B));
        if (dot(outward, eye) > 0.0) {
            outward = -outward;                   // make it face the camera
        }

        vec3  shaded;
        float alpha;
        vec3  depthPoint;

        if (style == RS_STYLE_BEAM) {
            if (!rs_beam(eye, T, B, faceCentre, outward, RS_UP, rsTint.rgb,
                         shaded, alpha, depthPoint)) {
                discard;
            }
        } else {

        // ------------------------------------------------------------- orb ---
        // The orb path has to assume a cube: one face gives you two of the box's
        // three extents, and nothing recovers the third. Non-uniform scale
        // therefore averages into a sphere rather than an ellipsoid.
        float edge = 0.5 * (length(T) + length(B));

        vec3  centre = faceCentre - outward * (edge * 0.5);
        float radius = edge * 0.5 * RS_FILL;

        // Ray-sphere intersection with the ray origin at the camera (0,0,0).
        float b = dot(eye, centre);
        if (b <= 0.0) {
            discard;                              // orb is behind the camera
        }
        float c = dot(centre, centre) - radius * radius;
        float disc = b * b - c;

        if (disc < 0.0) {
            if (style == RS_STYLE_EYE) {
                discard;    // an eye reads as a solid object; no glow halo
            }
            // Miss: draw the outer glow rather than nothing. disc = r^2 - d^2,
            // so the ray's perpendicular distance to the centre falls straight
            // out of the same discriminant.
            float d = sqrt(max(0.0, radius * radius - disc));
            float h = 1.0 - smoothstep(radius, radius * RS_HALO, d);
            h = pow(h, 2.2);
            if (h * 0.8 < RS_MIN_ALPHA) {
                discard;                              // see RS_MIN_ALPHA
            }
            shaded     = rsTint.rgb * 1.7;
            alpha      = h * 0.8;
            depthPoint = eye * b;                 // ray's closest approach
        } else {
            float root = sqrt(disc);
            float t = b - root;
            if (t < 0.0) {
                t = b + root;                     // camera inside the sphere
            }
            if (t < 0.0) {
                discard;
            }
            vec3 hit = eye * t;
            vec3 normal = normalize(hit - centre);
            float ndv = clamp(dot(normal, -eye), 0.0, 1.0);

            shaded     = rs_orb_colour(style, rsTint.rgb, normal, ndv, -normalize(centre), rsTime);
            alpha      = 1.0;
            depthPoint = hit;
        }

        }   // ------------------------------------------------- end orb path ---

        // Project the chosen point ourselves, using the ProjMat coefficients
        // handed down from the vertex stage, and write the depth it really has.
        float zView = (ModelViewMat * vec4(depthPoint, 1.0)).z;
        float clipZ = rsProjZW.x * zView + rsProjZW.y;
        float clipW = rsProjZW.z * zView + rsProjZW.w;
        gl_FragDepth = 0.5 + 0.5 * (clipZ / clipW);

        // No lightmap: orbs and beams are emissive, so they glow in the dark
        // rather than going black in a cave.
        fragColor = apply_fog(vec4(shaded * ColorModulator.rgb, alpha * ColorModulator.a),
                              fog_spherical_distance(depthPoint),
                              fog_cylindrical_distance(depthPoint),
                              FogEnvironmentalStart, FogEnvironmentalEnd,
                              FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
        return;
    }

    // ------------------------------------------------------- vanilla path ----
    gl_FragDepth = gl_FragCoord.z;

    vec4 color = texel * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
