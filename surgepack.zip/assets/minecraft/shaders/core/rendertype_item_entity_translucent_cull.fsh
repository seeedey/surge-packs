#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec4 flatColor; // my thing :3

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor; // Read color from texture

    // Override specifically opacity 98 (should also be 252 on a 0-255 range)
    int alpha = int(floor(color.w * 100));
    if(alpha == 98) {
        fragColor = vec4(flatColor.rgb, 1.0); // Set color to flat version of its intended color
        return;
    }

    color *= ColorModulator; // Multiplying by ColorModulator beforehand broke stuff


    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
