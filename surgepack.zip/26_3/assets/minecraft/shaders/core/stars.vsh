#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

// Vanilla 26.3 stars.vsh, plus streaks.
//
// Star brightness arrives as ColorModulator, all four channels. Vanilla never takes it past 0.5, so
// the part above that is free: the opening's timeline pushes it towards 1.0 while the sky is torn and
// the field turns, and this smears each star back along the way the field is turning.

layout(location = 0) in vec3 Position;

layout(location = 0) out float starTail;

void main() {
    vec3 pos = Position;
    starTail = 0.0;
    float streak = clamp((ColorModulator.a - 0.52) / 0.48, 0.0, 1.0);
    // Quads come through as four consecutive vertices, so corners 2 and 3 are one edge of each star.
    // Dragging that edge back along the motion stretches the star into a streak.
    if (streak > 0.0 && (gl_VertexID & 3) >= 2) {
        // The field turns about its own X axis as star_angle advances.
        vec3 motion = vec3(0.0, -pos.z, pos.y);
        float len = length(motion);
        if (len > 0.001) {
            pos -= motion / len * streak * 14.0;
        }
        starTail = 1.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
