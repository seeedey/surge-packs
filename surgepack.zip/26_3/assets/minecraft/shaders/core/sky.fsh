#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:surge_opening_data.glsl>
#include <minecraft:surge_opening_sky.glsl>

// Vanilla 26.3 sky.fsh, plus the Season 2 opening's sky. Outside the opening this is vanilla exactly.

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

void main() {
    if (!os_active(ColorModulator)) {
        fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
        return;
    }
    fragColor = vec4(os_sky(normalize(skyPos), ColorModulator), ColorModulator.a);
}
