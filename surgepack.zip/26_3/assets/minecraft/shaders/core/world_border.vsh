#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

// Vanilla 26.3 world_border.vsh, plus what surge_border.glsl needs to draw the wall itself: where on
// the wall a point is, in blocks, and the wall's own clock.
//
// What the game feeds this pass (WorldBorderRenderer, checked against the 26.3 client jar; unchanged
// since 1.21.11):
//   Position     the wall's vertex, x and z from the border's west and north bounds, y the world's
//   ModelOffset  (west - camera x, -camera y, north - camera z)
//   TextureMat   a translation (f, f) with f = (milliseconds % 3000) / 3000: a clock with a 3 s period
//   ColorModulator  the border's stage colour, alpha the vanilla fade with the distance to the wall

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec3 wallPos;
layout(location = 2) out float wallClock;
layout(location = 3) out float eyeY;

void main() {
    vec3 pos = Position + ModelOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    wallPos = Position;
    wallClock = TextureMat[3][0];
    eyeY = -ModelOffset.y;
}
