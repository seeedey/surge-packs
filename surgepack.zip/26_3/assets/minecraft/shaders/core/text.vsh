#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#define SURGE_WORLD_TEXT
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

// Vanilla 26.3 text.vsh, plus Surge's effects (port of the 1.21.11 rendertype_text and
// rendertype_text_see_through shaders, surgepack v27). 26.3 draws every text pipeline with this one
// shader and tells the variants apart by defines:
//   IS_GUI          GUI text (titles, chat, tooltips): the fullscreen effects and gold text live here
//   IS_SEE_THROUGH  see_through text displays: world effects, no push, no fog (the supernova)
//   neither         world text (signs, text displays, name tags): world effects and gold text
// Every glyph that is not one of ours is drawn exactly as vanilla.
//
// HOW AN EFFECT GETS ON SCREEN. The plugin sends a title made of glyphs from overlays:fx (and the old
// overlays:fullscreen_*). Each of those glyphs is a solid block of one KEY colour that no real glyph
// uses. This shader samples the glyph's own texture; a key colour turns the glyph's quad into the whole
// screen, and the glyph's text colour carries the effect's three parameters (r, g, b, 0..255 each).
// No text pipeline gets the Globals block, so there is no GameTime here: anything that moves is moved
// by the plugin sending new parameters every tick.
//
// Keys (texture rgb):  215 40 255  tint       (the old Overlay.flash sheet, e800)
//                      215 41 255  bloom      r strength, g progress, b palette | phase << 4
//                      215 42 255  vignette   r strength, g pulse,    b palette | phase << 4
//                      215 43 255  crack      r strength, g opening,  b palette | seed << 3
//                      215 44 255  letterbox  r bar size
//                      215 50..55 255  world effects (text displays), drawn by surge_world_fx.glsl
//
// Which corner of the screen a vertex goes to comes from the glyph's vertex order: top-left,
// bottom-left, bottom-right, top-right, four vertices to a glyph (BakedSheetGlyph.render, checked
// against the 26.3 client jar: unchanged since 1.21.11). The same order says which way is into the
// glyph, so the key is sampled a texel and a half in from the vertex's own UV.
//
// World glows that stand up (halo, beam, nova, seam) are pushed back along the view ray by a little
// (at most 15% of the distance): the quad lands on screen exactly where it was, but behind what stands
// in its light, so the depth it writes does not hide those particles.

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#ifdef SURGE_WORLD_TEXT
layout(location = 3) in ivec2 UV2;
#endif

uniform sampler2D Sampler0;

#ifdef SURGE_WORLD_TEXT
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) flat out int fxKind;
layout(location = 5) out vec2 fxPos;
layout(location = 6) flat out vec4 fxParams;
layout(location = 7) flat out float fxAspect;

// Per vertex of a glyph: where it goes on screen, and which way (in UV) is into the glyph.
const vec2 CORNER[4] = vec2[](vec2(-1.0, 1.0), vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0));
const vec2 INWARD[4] = vec2[](vec2(1.0, 1.0), vec2(1.0, -1.0), vec2(-1.0, -1.0), vec2(-1.0, 1.0));

int keyAt(vec2 uv) {
    vec4 c = textureLod(Sampler0, uv, 0.0);
    if (c.a < 0.99) {
        return 0;
    }
    ivec3 k = ivec3(round(c.rgb * 255.0));
    if (k.r != 215 || k.b != 255) {
        return 0;
    }
    if (k.g >= 40 && k.g <= 44) {
        return k.g - 39;
    }
    if (k.g >= 50 && k.g <= 55) {
        return k.g - 30;          // 20..25: world effects
    }
    return 0;
}

/** How far a standing glow is pushed back along the view ray, in blocks, before the 15% cap. */
float worldPush(int kind) {
    return kind == 20 ? 1.5 : (kind == 23 ? 0.6 : (kind == 24 ? 5.0 : (kind == 25 ? 0.4 : 0.0)));
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef SURGE_WORLD_TEXT
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
    fxKind = 0;
    fxPos = vec2(0.0);
    fxParams = Color;
    fxAspect = 1.0;

    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    int v = gl_VertexID % 4;

#ifdef IS_GUI
    // Only GUI glyphs pushed thousands of units down by a huge negative ascent can be ours.
    if (Position.y > 2000.0 && Color.a > 0.02) {
        int key = keyAt(UV0 + INWARD[v] * texel * 1.5);
        if (key > 0 && key < 20) {
            fxKind = key;
            gl_Position = vec4(CORNER[v], 0.0, 1.0);
            fxPos = CORNER[v];
            float sx = abs(ProjMat[0][0]);
            float sy = abs(ProjMat[1][1]);
            fxAspect = sx > 0.0 ? sy / sx : 16.0 / 9.0;
        }
    }
#else
    // World effects: a glyph from overlays:world on a text display.
    int key = keyAt(UV0 + INWARD[v] * texel * 1.5);
    if (key >= 20) {
        fxKind = key;
        fxPos = CORNER[v];
#ifdef SURGE_WORLD_TEXT
        vec4 view = ModelViewMat * vec4(Position, 1.0);
        float d = length(view.xyz);
        float push = min(d * 0.15, worldPush(key));
        if (push > 0.0 && d > 0.01) {
            view.xyz *= (d + push) / d;
        }
        gl_Position = ProjMat * view;
#endif
    }
#endif

#ifndef IS_SEE_THROUGH
    // Gold names and lore, not their shadows (a shadow is the colour at a quarter).
    if (fxKind == 0) {
        ivec3 c = ivec3(round(Color.rgb * 255.0));
        if (c == ivec3(255, 215, 0)) {
            fxKind = 9;
            fxPos = vec2(v >= 2 ? 1.0 : 0.0, (v == 1 || v == 2) ? 1.0 : 0.0);
        }
    }
#endif
}
