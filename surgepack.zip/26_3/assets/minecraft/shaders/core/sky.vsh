#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:surge_opening_data.glsl>
#include <minecraft:surge_opening_sky.glsl>

// Vanilla 26.3 sky.vsh, plus the Season 2 opening's sky. Outside the opening this is vanilla exactly.

layout(location = 0) in vec3 Position;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec3 skyPos;

void main() {
    vec3 pos = Position;
    // While the opening runs, the top disc's rim is pulled down below the horizon, which turns the
    // disc into a cone, so the storm runs on down behind the hills. The fragment shader works from
    // direction alone, so the cone's facets never show. The dark disc under the world (y = -16) stays.
    if (os_active(ColorModulator) && pos.y > 0.0 && length(pos.xz) > 1.0) {
        pos.y = -256.0;
    }
    skyPos = pos;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
}
