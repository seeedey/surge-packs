#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:surge_border.glsl>

// Vanilla 26.3 world_border.fsh, with the wall drawn by surge_border.glsl. The vanilla stripes stay
// underneath at a fifth of their light, so the wall still reads as the border. The OIT variant
// (OIT_ADDITIVE) gets the colour through vanilla's accumulate / alpha-only steps.

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec3 wallPos;
layout(location = 2) in float wallClock;
layout(location = 3) in float eyeY;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

void main() {
    vec4 stripes = texture(Sampler0, texCoord0);
    vec4 wall = sb_wall(wallPos, wallClock, eyeY, ColorModulator.rgb);
    float a = clamp(wall.a + stripes.a * 0.2, 0.0, 1.0) * ColorModulator.a;
    if (a <= 0.002) {
        discard;
    }
    vec3 col = (wall.rgb * wall.a + ColorModulator.rgb * stripes.a * 0.2) / max(wall.a + stripes.a * 0.2, 1e-3);
    vec4 color = vec4(col, a);

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif
    fragColor = color;
    #endif
}
