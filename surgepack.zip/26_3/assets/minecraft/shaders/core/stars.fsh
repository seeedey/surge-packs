#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>

// Vanilla 26.3 stars.fsh, plus the streaks from stars.vsh fading from head to tail.

layout(location = 0) in float starTail;

layout(location = 0) out vec4 fragColor;

void main() {
    if (ColorModulator.a <= 0.52) {
        fragColor = ColorModulator;
        return;
    }
    float lit = min(ColorModulator.a, 1.0);
    fragColor = vec4(vec3(lit), lit * mix(1.0, 0.1, starTail));
}
