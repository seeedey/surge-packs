#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#define SURGE_WORLD_TEXT
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:surge_world_fx.glsl>

// Vanilla 26.3 text.fsh, plus Surge's effects. See text.vsh for how an effect is chosen and where its
// parameters come from, and for which variant (IS_GUI, IS_SEE_THROUGH, world) draws which. Each
// fullscreen effect is a formula of the screen position q (centre 0, height -1..1, width scaled by the
// aspect ratio):
//
//   tint       the colour asked for, heavier toward the edges:   a = 0.45 + 0.4*smoothstep(0.2, 1.4, |q|)
//   bloom      a white wash (1-p)^2, a ring at r = 0.1 + 1.6p, twelve rays cos(12t)^12*e^(-1.2r) and a
//              hot core e^(-r^2/s^2); p is the progress the plugin counts 0 -> 1
//   vignette   edges in a colour, their inner radius breathing with the pulse and rippling
//   crack      a jagged seeded line across the screen, opening outward from the middle, with branches
//   letterbox  black bars top and bottom
//
// Gold (#FFD700) text gets a vertical gradient, pale at the top of each glyph and deep at the foot.
//
// World effects (fxKind 20..25) are drawn by surge_world_fx.glsl. Light cuts through fog: an effect
// keeps 30% of itself however deep in the fog it stands. The OIT variants get our colours through the
// same accumulate / alpha-only steps vanilla uses.

uniform sampler2D Sampler0;

#ifdef SURGE_WORLD_TEXT
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) flat in int fxKind;
layout(location = 5) in vec2 fxPos;
layout(location = 6) flat in vec4 fxParams;
layout(location = 7) flat in float fxAspect;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #ifdef SURGE_WORLD_TEXT

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

/** Writes one of our own colours: no fog, but through the OIT steps like any other fragment. */
void emitEffect(vec4 c) {
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, c.a);
    #else
    #ifdef OIT_ACCUMULATE
    c = sampleColorForAccumulation(c);
    #endif
    fragColor = c;
    #endif
}

#ifdef IS_GUI
const vec3 PALETTE[16] = vec3[](
    vec3(0.95, 0.93, 1.00),   // 0 white
    vec3(0.73, 0.66, 1.00),   // 1 lavender
    vec3(0.48, 0.30, 1.00),   // 2 violet
    vec3(0.95, 0.70, 0.35),   // 3 gold
    vec3(0.50, 0.89, 1.00),   // 4 soul
    vec3(0.66, 0.71, 0.78),   // 5 steel
    vec3(1.00, 0.70, 0.48),   // 6 dawn
    vec3(0.62, 0.91, 1.00),   // 7 cold
    vec3(1.00, 0.48, 0.18),   // 8 ember
    vec3(0.16, 0.09, 0.31),   // 9 deep
    vec3(0.00, 0.00, 0.00),   // 10 black
    vec3(1.00, 0.56, 0.72),   // 11 rose
    vec3(0.16, 0.57, 0.96),   // 12 water
    vec3(0.96, 0.90, 0.34),   // 13 lightning
    vec3(0.71, 0.15, 0.96),   // 14 gravity
    vec3(0.84, 1.00, 0.98)    // 15 ice
);

float hash1(float n) {
    return fract(sin(n * 127.1 + 311.7) * 43758.5453);
}

float tri(float x) {
    return abs(fract(x) - 0.5) * 4.0 - 1.0;
}

// The crack's centre line: offset from the straight line at distance x along it.
float jag(float x, float seed) {
    return 0.050 * tri(x * 1.7 + seed) + 0.022 * tri(x * 4.3 + seed * 2.1) + 0.009 * tri(x * 11.0 - seed * 1.3);
}

vec4 tint(vec2 q) {
    float a = 0.45 + 0.4 * smoothstep(0.2, 1.4, length(q));
    return vec4(vertexColor.rgb, vertexColor.a * a);
}

vec4 bloom(vec2 q, vec3 p) {
    int b = int(round(p.b * 255.0));
    vec3 pal = PALETTE[b & 15];
    float phase = float(b >> 4) / 16.0;
    float prog = p.g;
    float fade = 1.0 - prog;
    float r = length(q);
    float th = atan(q.y, q.x);
    float wash = fade * fade;
    float ringR = 0.1 + 1.6 * prog;
    float ring = exp(-pow((r - ringR) / (0.05 + 0.12 * prog), 2.0)) * fade;
    float rays = pow(max(cos(12.0 * th + phase * 6.2831853 + 0.6 * sin(th * 3.0 + phase * 9.0)), 0.0), 12.0)
            * exp(-1.2 * r) * fade;
    float core = exp(-r * r / (0.02 + 0.25 * fade)) * fade;
    float a = p.r * clamp(0.85 * wash + 0.7 * ring + 0.45 * rays + 0.8 * core, 0.0, 1.0);
    vec3 col = mix(pal, vec3(1.0), clamp(core + 0.5 * wash, 0.0, 1.0));
    return vec4(col, a);
}

vec4 vignette(vec2 q, vec3 p) {
    int b = int(round(p.b * 255.0));
    vec3 pal = PALETTE[b & 15];
    float phase = float(b >> 4) / 16.0 * 6.2831853;
    vec2 e = q / vec2(fxAspect, 1.0);
    float r = length(e);
    float th = atan(e.y, e.x);
    float wob = 0.03 * sin(5.0 * th + phase) + 0.015 * sin(11.0 * th - 2.0 * phase);
    float inner = 0.70 - 0.22 * p.g + wob;
    float edge = smoothstep(inner, inner + 0.85, r);
    return vec4(pal * (0.55 + 0.6 * edge), p.r * edge * (0.6 + 0.4 * p.g));
}

vec4 crack(vec2 q, vec3 p) {
    int b = int(round(p.b * 255.0));
    vec3 pal = PALETTE[b & 7];
    float seed = float(b >> 3);
    float ang = (hash1(seed) - 0.5) * 0.9;
    vec2 dir = vec2(cos(ang), sin(ang));
    vec2 nrm = vec2(-dir.y, dir.x);
    float x = dot(q, dir);
    float y = dot(q, nrm) - (hash1(seed + 7.0) - 0.5) * 0.4;
    float reach = p.g * (fxAspect + 0.4);
    float shown = 1.0 - smoothstep(reach - 0.05, reach, abs(x));
    float d = abs(y - jag(x, seed));
    float width = 0.0035 + 0.003 * p.g;
    float core = exp(-pow(d / width, 2.0)) * shown;
    float halo = exp(-d / 0.03) * shown;
    float leak = exp(-d / 0.14) * shown * 0.35;
    // branches off the main line
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float bx = (hash1(seed * 3.0 + fi) - 0.5) * 1.6 * fxAspect;
        if (abs(bx) > reach) {
            continue;
        }
        vec2 root = dir * bx + nrm * (jag(bx, seed) + (hash1(seed + 7.0) - 0.5) * 0.4);
        float ba = ang + (hash1(seed + fi * 5.0) > 0.5 ? 1.0 : -1.0) * (0.6 + 0.5 * hash1(seed + fi * 9.0));
        vec2 bd = vec2(cos(ba), sin(ba));
        vec2 rel = q - root;
        float along = dot(rel, bd);
        float len = (0.15 + 0.25 * hash1(seed + fi * 13.0)) * smoothstep(abs(bx), abs(bx) + 0.3, reach);
        if (along > 0.0 && along < len) {
            float bdist = abs(dot(rel, vec2(-bd.y, bd.x)) - 0.4 * jag(along * 2.0, seed + fi));
            float taper = 1.0 - along / len;
            core = max(core, exp(-pow(bdist / (width * taper + 1e-4), 2.0)) * taper);
            halo = max(halo, exp(-bdist / 0.02) * taper * 0.7);
        }
    }
    vec3 col = mix(pal, vec3(1.0), clamp(core, 0.0, 1.0));
    return vec4(col, p.r * clamp(core + 0.6 * halo + leak, 0.0, 1.0));
}

vec4 letterbox(vec2 q, vec3 p) {
    float bar = p.r * 0.13 * 2.0;
    float y = 1.0 - abs(fxPos.y);
    return vec4(0.0, 0.0, 0.0, 1.0 - smoothstep(bar - 0.004, bar, y));
}
#endif

void main() {
#ifndef IS_GUI
    if (fxKind >= 20) {
        vec4 w = wfx(fxKind, fxPos, fxParams);
#ifdef SURGE_WORLD_TEXT
        float fogged = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart,
                FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd);
        w.a *= 1.0 - 0.7 * fogged * FogColor.a;
        if (w.a < 0.01) {
            discard;
        }
#else
        w *= ColorModulator;
        if (w.a < 0.004) {
            discard;
        }
#endif
        emitEffect(w);
        return;
    }
#else
    if (fxKind > 0 && fxKind < 9) {
        vec2 q = fxPos * vec2(fxAspect, 1.0);
        vec3 p = fxParams.rgb;
        vec4 c;
        if (fxKind == 1) {
            c = tint(q);
        } else if (fxKind == 2) {
            c = bloom(q, p);
        } else if (fxKind == 3) {
            c = vignette(q, p);
        } else if (fxKind == 4) {
            c = crack(q, p);
        } else {
            c = letterbox(q, p);
        }
        c.a *= fxParams.a;
        if (c.a < 0.004) {
            discard;
        }
        emitEffect(c);
        return;
    }
#endif

    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    if (fxKind == 9) {
        vec3 top = vec3(1.0, 0.95, 0.62);
        vec3 foot = vec3(0.86, 0.52, 0.10);
        color.rgb = mix(top, foot, smoothstep(0.1, 0.95, fxPos.y)) * texColor.rgb;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
