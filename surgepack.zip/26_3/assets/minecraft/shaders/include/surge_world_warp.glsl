#ifndef SURGE_WORLD_WARP_GLSL
#define SURGE_WORLD_WARP_GLSL

// The Season 2 opening's world warp (pack v23): the world itself, not the screen, twists in on Pandora
// at the climax and is thrown back out by a shockwave when she breaks. It replaced the Nausea warp.
//
// The signal. The terrain pass sees no sky colour and no ColorModulator, but it does see the Fog block.
// The surge_opening timeline holds the environmental fog end at 160 through the break; during the warp
// it writes 160.5 + 0.4 * w instead (make-opening-sky.py, warp_fog_end), half a block of fog nobody can
// see. w 0..0.6 is the swirl building, 0.6..1 the shockwave running out. Nothing else in the game puts an
// environmental fog end in 160.45..160.95, and the lift after the warp jumps straight over it.
//
// Centre: OS_CORE (the core's block centre, baked by make-opening-sky.py --core-x/--core-z), so the warp
// only works if config core.x/z match the pack. Cylindrical: the world turns round her vertical axis.

const float WW_LO = 160.45;
const float WW_HI = 160.95;
const float WW_SWIRL = 0.6;

// The warp's phase, -1 when off.
float ww_phase(float fogEnd) {
    if (fogEnd < WW_LO || fogEnd > WW_HI) {
        return -1.0;
    }
    return clamp((fogEnd - 160.5) / 0.4, 0.0, 1.0);
}

vec2 ww_rot(vec2 v, float a) {
    float c = cos(a);
    float s = sin(a);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

// world: the vertex's absolute world position. ticks: GameTime in ticks (for the wobble).
vec3 ww_warp(vec3 world, float phase, float ticks) {
    if (phase < 0.0) {
        return world;
    }
    vec2 d = world.xz - OS_CORE;
    float r = length(d);
    if (r > 96.0) {
        return world;
    }
    float swirl;
    float wave;
    if (phase <= WW_SWIRL) {
        float k = phase / WW_SWIRL;
        swirl = k * k * (3.0 - 2.0 * k);
        wave = -1.0;
    } else {
        float p = (phase - WW_SWIRL) / (1.0 - WW_SWIRL);
        // the twist snaps back as the shock leaves her
        swirl = pow(1.0 - smoothstep(0.0, 0.35, p), 2.0);
        wave = p;
    }

    // the swirl: turn round her, more the nearer, with a slow wobble so it breathes; then pull in
    float fall = exp(-r / 16.0);
    float wob = sin(ticks * 0.21 - r * 0.35);
    float angle = swirl * (1.25 * fall + 0.12 * wob * exp(-r / 40.0));
    vec2 nd = ww_rot(d, angle);
    float pull = 1.0 - swirl * 0.3 * exp(-r / 11.0);
    nd *= pull;
    float y = world.y;
    // the ground heaves in rings that run inward, as if poured into her
    y += swirl * 0.55 * sin(r * 0.7 + ticks * 0.45) * exp(-r / 24.0);
    // and is drawn up toward her a little
    y += swirl * 1.4 * exp(-r / 7.0);

    if (wave >= 0.0) {
        // the shockwave: a crest racing out to 90 blocks, lifting and shoving outward, dying as it goes
        float front = sqrt(wave) * 90.0;   // bursts out fast, then slows (the timeline eases w)
        float x = (r - front) / (2.5 + 4.0 * wave);
        float crest = exp(-x * x) * (1.0 - wave);
        float wake = sin((r - front) * 0.9) * exp(-max(front - r, 0.0) / 6.0) * step(r, front) * (1.0 - wave);
        y += 2.2 * crest + 0.35 * wake;
        if (r > 0.001) {
            nd += (nd / max(length(nd), 0.001)) * 1.2 * crest;
        }
    }
    return vec3(OS_CORE.x + nd.x, y, OS_CORE.y + nd.y);
}

#endif
