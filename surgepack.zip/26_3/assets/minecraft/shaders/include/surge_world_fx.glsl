#ifndef SURGE_WORLD_FX_GLSL
#define SURGE_WORLD_FX_GLSL

// Surge world effects: light drawn by the text shader on a text display in the world (surgepack v22).
//
// HOW. The plugin spawns a text display holding one glyph from overlays:world. Each of those glyphs is a
// solid block of one KEY colour (215, 50..55, 255); rendertype_text.vsh sees the key, keeps the glyph's
// quad where the display put it (its size, place, turn and billboard all come from the display's own
// transformation, which the client interpolates smoothly), and hands this file the quad's own
// coordinates q (-1..1, x right, y up as seen from the front) and the glyph's colour as parameters:
//
//   r, g     two numbers 0..1, re-sent by the plugin when they change (20 times a second at most)
//   b        low 5 bits: the colour (WFX_PAL), high 3 bits: a variant
//   a        a smooth number 0..1: the display's text opacity, which the client interpolates every
//            frame. It is a signed byte on the wire, so it is decoded as one (wfx_smooth).
//
// The text pipeline has no GameTime, so motion is the display's own (turns and scales interpolated by
// the client) plus the smooth number; nothing here reads a clock.
//
// Kinds (key green -> fxKind):
//   50 halo    a glow: white-hot core, coloured bloom, n rays, a streak     r size, g rays, a strength
//   51 sigil   a magic circle lying on the ground, written on by r          r reveal, g pulse radius, a strength
//   52 ring    a shockwave ring at the quad's edge (the display's scale is its radius)
//                                                                            r width, g wake, a strength
//   53 beam    a pillar of light (vertical billboard), rising streaks       r strength, g helix, a phase
//   54 nova    the supernova: a shell running out, twelve coloured rays     r strength, g rays, a progress
//   55 seam    the hairline where she stands, opening                       r open, g strength, a phase
//   56 lens    the Proctor's eye (Trials): its own entry, wfx_lens, below     r,g gaze yaw/pitch, a phase

const float WFX_TAU = 6.28318531;

// 0..15 as the screen palette (rendertype_text.fsh), 16..29 the fourteen elements in Element order
// (their HUD colours, Earth lifted so it glows), 30 gold-pale, 31 void violet.
const vec3 WFX_PAL[32] = vec3[](
    vec3(0.95, 0.93, 1.00), vec3(0.73, 0.66, 1.00), vec3(0.48, 0.30, 1.00), vec3(0.95, 0.70, 0.35),
    vec3(0.50, 0.89, 1.00), vec3(0.66, 0.71, 0.78), vec3(1.00, 0.70, 0.48), vec3(0.62, 0.91, 1.00),
    vec3(1.00, 0.48, 0.18), vec3(0.16, 0.09, 0.31), vec3(0.00, 0.00, 0.00), vec3(1.00, 0.56, 0.72),
    vec3(0.16, 0.57, 0.96), vec3(0.96, 0.90, 0.34), vec3(0.71, 0.15, 0.96), vec3(0.84, 1.00, 0.98),
    vec3(1.00, 0.48, 0.10),   // 16 fire
    vec3(0.96, 0.90, 0.34),   // 17 lightning
    vec3(0.15, 0.57, 0.96),   // 18 water
    vec3(0.84, 0.58, 0.22),   // 19 earth
    vec3(0.86, 0.88, 0.92),   // 20 air
    vec3(0.71, 0.15, 0.96),   // 21 gravity
    vec3(0.95, 0.24, 1.00),   // 22 health
    vec3(0.96, 0.78, 0.15),   // 23 time
    vec3(0.84, 1.00, 0.98),   // 24 ice
    vec3(0.89, 0.91, 1.00),   // 25 lunar
    vec3(0.72, 0.20, 0.25),   // 26 spider
    vec3(0.56, 0.64, 0.75),   // 27 disable
    vec3(1.00, 0.36, 0.36),   // 28 strength
    vec3(1.00, 0.69, 0.41),   // 29 comet
    vec3(1.00, 0.89, 0.64),   // 30 gold-pale
    vec3(0.36, 0.20, 0.85)    // 31 void violet
);

/** The opacity byte as the 0..1 it was sent as: signed on the wire, -128..127 -> 0..1. */
float wfx_smooth(float a) {
    int ai = int(round(a * 255.0));
    int s = ai >= 128 ? ai - 256 : ai;
    return clamp((float(s) + 128.0) / 255.0, 0.0, 1.0);
}

float wfx_hash(vec2 p) {
    p = fract(p * vec2(127.1, 311.7));
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
}

/** Value noise, x wrapping every px cells and y every py (so a flow over a whole period is seamless). */
float wfx_noise(vec2 p, vec2 period) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    vec2 i0 = mod(i, period);
    vec2 i1 = mod(i + 1.0, period);
    float a = wfx_hash(i0);
    float b = wfx_hash(vec2(i1.x, i0.y));
    float c = wfx_hash(vec2(i0.x, i1.y));
    float d = wfx_hash(i1);
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

/** Distance from p to the segment ab. */
float wfx_seg(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a;
    vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
    return length(pa - ba * h);
}

/** A drawn line of half-width w at distance d: a hard bright core and a soft halo, as one brightness. */
float wfx_ink(float d, float w, float aa) {
    float ww = max(w, aa);
    return exp(-(d * d) / (ww * ww)) + 0.15 * exp(-d / (ww * 3.0));
}

/** How much of a layer is written: its own 0..1 out of the whole reveal, by its window [w0, w1]. */
float wfx_window(float reveal, float w0, float w1) {
    return clamp((reveal - w0) / (w1 - w0), 0.0, 1.0);
}

/**
 * The angular write-on of a ring-shaped layer: 1 where the pen has passed, plus a bright pen head.
 * u is the angle as 0..1 round the circle, done is how far round the pen has got.
 */
float wfx_written(float u, float done, float r) {
    if (done >= 1.0) {
        return 1.0;
    }
    float seen = step(u, done);
    float head = exp(-pow((u - done) * WFX_TAU * r / 0.03, 2.0)) * 2.5 * step(0.001, done);
    return seen + head;
}

/** The distance to a star polygon {n/k} of radius R, turned by rot. */
float wfx_star(vec2 q, int n, int k, float R, float rot) {
    float d = 1e3;
    for (int j = 0; j < 12; j++) {
        if (j >= n) {
            break;
        }
        float a0 = WFX_TAU * float(j) / float(n) + rot;
        float a1 = WFX_TAU * float(j + k) / float(n) + rot;
        d = min(d, wfx_seg(q, R * vec2(cos(a0), sin(a0)), R * vec2(cos(a1), sin(a1))));
    }
    return d;
}

/**
 * A rune: up to sixteen strokes on a 3 x 3 grid of points (rows, columns and both diagonals of each
 * square), kept by bits of a hash, so every cell of a band reads as a different letter. p is in the
 * cell, 0..1 each way.
 */
float wfx_rune(vec2 p, float seed) {
    float d = 1e3;
    float h1 = wfx_hash(vec2(seed, 7.1));
    float h2 = wfx_hash(vec2(seed, 3.7));
    int bits = int(h1 * 65535.0);
    int keep = int(h2 * 65535.0) | int(wfx_hash(vec2(seed, 1.3)) * 65535.0);
    for (int s = 0; s < 16; s++) {
        if (((bits >> s) & 1) == 0 || ((keep >> s) & 1) == 0) {
            continue;
        }
        vec2 a;
        vec2 b;
        if (s < 6) {            // rows: three rows of two strokes
            float row = float(s / 2) * 0.5;
            float col = float(s % 2) * 0.5;
            a = vec2(col, row);
            b = vec2(col + 0.5, row);
        } else if (s < 12) {    // columns
            int c = s - 6;
            float col = float(c / 2) * 0.5;
            float row = float(c % 2) * 0.5;
            a = vec2(col, row);
            b = vec2(col, row + 0.5);
        } else {                // diagonals of the four squares
            int c = s - 12;
            float x0 = float(c % 2) * 0.5;
            float y0 = float(c / 2) * 0.5;
            bool up = wfx_hash(vec2(seed, float(c) + 9.0)) > 0.5;
            a = vec2(x0, up ? y0 : y0 + 0.5);
            b = vec2(x0 + 0.5, up ? y0 + 0.5 : y0);
        }
        d = min(d, wfx_seg(p, a, b));
    }
    return d;
}

// ---------------------------------------------------------------- halo

vec4 wfx_halo(vec2 q, vec3 p, float strength) {
    int b = int(round(p.b * 255.0));
    vec3 col = WFX_PAL[b & 31];
    int variant = b >> 5;
    float n = float(variant == 0 ? 0 : (variant == 1 ? 4 : (variant == 2 ? 6 : (variant == 3 ? 8 : (variant == 4 ? 12 : 16)))));
    float r = length(q);
    float th = atan(q.y, q.x);
    if (r > 1.0) {
        return vec4(0.0);
    }
    float size = 0.25 + 0.75 * p.r;
    float core = exp(-r * r / (0.0025 + 0.012 * size));
    float bloom = exp(-r / (0.06 + 0.10 * size));
    float wide = 0.10 * exp(-r * r / (0.05 + 0.06 * size));
    float rays = n > 0.0 ? pow(abs(cos(th * n * 0.5)), 48.0) * exp(-r / (0.22 + 0.25 * p.g)) * p.g : 0.0;
    float streak = exp(-abs(q.y) / 0.010) * exp(-abs(q.x) / (0.25 + 0.35 * p.g)) * p.g * 0.7;
    float ring = 0.0;   // no circle round a halo
    float edge = 1.0 - smoothstep(0.8, 1.0, r);
    float v = (core * 1.3 + bloom * 0.5 + wide + rays + streak + ring) * edge;
    vec3 c = mix(col, vec3(1.0), clamp(core * 1.4 + bloom * 0.25, 0.0, 1.0));
    return vec4(c, clamp(v, 0.0, 1.0) * strength);
}

// ---------------------------------------------------------------- sigil

/**
 * The magic circle. Variants: 0 the outer medallion (edge rings and ticks, the rune band, a braided
 * guilloché), 1 the inner medallion (two star polygons, a rose, rings, a hexagram heart), 2 a rune
 * point (ring, a star from the element, the fill arc r draws round it), 3 a grant medallion (rose,
 * star, rings, heart, written on by r).
 */
vec4 wfx_sigil(vec2 q, vec3 p, float strength) {
    int b = int(round(p.b * 255.0));
    vec3 col = WFX_PAL[b & 31];
    int variant = b >> 5;
    float reveal = p.r;
    float r = length(q);
    float aa = fwidth(r) * 1.2;
    if (r > 1.0) {
        return vec4(0.0);
    }
    float th = atan(q.y, q.x);
    float u = th / WFX_TAU + 0.5;
    float ink = 0.0;
    float fill = 0.0;

    if (variant == 0) {
        // the rim: two rings with seventy-two ticks between, written first
        float w0 = wfx_window(reveal, 0.0, 0.25);
        float rim = wfx_ink(abs(r - 0.985), 0.0035, aa) + wfx_ink(abs(r - 0.952), 0.0022, aa);
        float tickArc = abs(fract(u * 72.0 + 0.5) - 0.5) / 72.0 * WFX_TAU * r;
        float tick = (r > 0.958 && r < 0.98) ? wfx_ink(tickArc, 0.0018, aa) * (fract(u * 72.0 / 6.0) < 1.0 / 6.0 ? 1.6 : 0.8) : 0.0;
        ink += (rim + tick) * wfx_written(u, w0, r);
        // the rune band: thirty letters between two rings
        float w1 = wfx_window(reveal, 0.18, 0.55);
        float band = wfx_ink(abs(r - 0.935), 0.002, aa) + wfx_ink(abs(r - 0.815), 0.0025, aa);
        if (r > 0.825 && r < 0.925) {
            float cells = 30.0;
            float cu = fract(u * cells);
            float cell = floor(u * cells);
            float cw = WFX_TAU * r / cells;
            vec2 cp = vec2((cu - 0.5) * cw / 0.09 + 0.5, (r - 0.835) / 0.08);
            if (cp.x > -0.15 && cp.x < 1.15) {
                float dr = wfx_rune(cp, cell + float(b & 31) * 31.0);
                band += wfx_ink(dr * 0.08, 0.0026, aa) * 1.1;
            }
        }
        ink += band * wfx_written(u, w1, r);
        // the guilloché: two braids of sine rings, 36 and 48 waves round, engraved rather than drawn
        float w2 = wfx_window(reveal, 0.45, 0.8);
        float g1 = min(abs(r - (0.745 + 0.011 * sin(36.0 * th))), abs(r - (0.745 + 0.011 * sin(36.0 * th + 3.14159))));
        float g2 = min(abs(r - (0.705 + 0.007 * sin(48.0 * th + 1.0))), abs(r - (0.705 + 0.007 * sin(48.0 * th + 4.14159))));
        float dots = abs(fract(u * 120.0 + 0.5) - 0.5) / 120.0 * WFX_TAU * r;
        float dotRing = (abs(r - 0.79) < 0.006) ? exp(-pow(length(vec2(dots, r - 0.79)) / 0.0045, 2.0)) : 0.0;
        ink += (wfx_ink(g1, 0.0016, aa) + 0.7 * wfx_ink(g2, 0.0013, aa) + dotRing * 1.2) * wfx_written(fract(u + 0.5), w2, r);
        fill = 0.05 * smoothstep(1.0, 0.3, r) * w0;
    } else if (variant == 1) {
        float w0 = wfx_window(reveal, 0.55, 0.75);
        float rings = wfx_ink(abs(r - 0.68), 0.003, aa) + wfx_ink(abs(r - 0.47), 0.0022, aa);
        ink += rings * wfx_written(u, w0, r);
        float w1 = wfx_window(reveal, 0.62, 0.85);
        if (r < 0.72 && w1 > 0.0) {
            float stars = wfx_ink(wfx_star(q, 9, 4, 0.66, 0.0), 0.0025, aa) * 1.1;
            stars += r < 0.5 ? wfx_ink(wfx_star(q, 5, 2, 0.45, 0.31), 0.0028, aa) : 0.0;
            ink += stars * wfx_written(fract(u + 0.25), w1, r);
        }
        // the rose r = R·|cos(5θ/3)|, three turns
        float w2 = wfx_window(reveal, 0.72, 0.92);
        if (r < 0.44 && w2 > 0.0) {
            float rose = 1e3;
            for (int j = 0; j < 3; j++) {
                rose = min(rose, abs(r - 0.40 * abs(cos(5.0 / 3.0 * (th + WFX_TAU * float(j))))));
            }
            ink += wfx_ink(rose, 0.0022, aa) * 0.9 * wfx_written(u, w2, r) * step(0.04, r);
        }
        // the heart: a hexagram in a ring
        float w3 = wfx_window(reveal, 0.85, 1.0);
        if (r < 0.26 && w3 > 0.0) {
            float heart = wfx_ink(wfx_star(q, 6, 2, 0.16, 0.0), 0.0025, aa) + wfx_ink(abs(r - 0.19), 0.002, aa)
                    + wfx_ink(abs(r - 0.07), 0.002, aa);
            ink += heart * w3;
        }
        fill = w3 * 0.5 * exp(-r * r / 0.004);
    } else if (variant == 2) {
        // a rune point: its ring, its star, and the fill arc a player stands up
        int n = 5 + (b & 31) % 5;
        int k = n / 2;
        float star = wfx_ink(wfx_star(q, n, k, 0.62, 0.0), 0.012, aa);
        float rings = wfx_ink(abs(r - 0.80), 0.010, aa) + wfx_ink(abs(r - 0.30), 0.008, aa);
        float arc = (abs(r - 0.92) < 0.06 && u < reveal) ? wfx_ink(abs(r - 0.92), 0.022, aa) * 1.5 : 0.0;
        ink = (star + rings) * (0.35 + 0.65 * p.g) + arc;
        fill = (0.12 + 0.25 * p.g) * smoothstep(0.85, 0.0, r);
    } else {
        // a grant medallion, written outside in
        int n = 5 + (b & 31) % 5;
        int k = n / 2;
        float w0 = wfx_window(reveal, 0.0, 0.35);
        float w1 = wfx_window(reveal, 0.25, 0.65);
        float w2 = wfx_window(reveal, 0.55, 1.0);
        float rings = wfx_ink(abs(r - 0.95), 0.006, aa) + wfx_ink(abs(r - 0.88), 0.004, aa);
        float rose = 1e3;
        float kk = float(2 + (b & 31) % 6);
        rose = abs(r - 0.82 * abs(cos(kk * 0.5 * th)));
        ink += (rings + wfx_ink(rose, 0.005, aa) * 0.8) * wfx_written(u, w0, r);
        ink += wfx_ink(wfx_star(q, n, k, 0.6, 0.0), 0.006, aa) * wfx_written(fract(u + 0.5), w1, r);
        ink += (wfx_ink(abs(r - 0.25), 0.006, aa) + wfx_ink(wfx_star(q, 6, 2, 0.2, 0.0), 0.005, aa)) * w2;
        fill = 0.10 * smoothstep(0.95, 0.0, r) * w0;
    }

    // a travelling pulse: a ring of extra light at radius g, from the plugin
    float pulse = p.g > 0.01 && variant != 2 ? 1.0 + 2.2 * exp(-pow((r - p.g) / 0.035, 2.0)) : 1.0;
    float edge = 1.0 - smoothstep(0.99, 1.0, r);
    float v = (ink * pulse + fill) * edge;
    vec3 c = mix(col, vec3(1.0), clamp(ink * 0.55 - 0.15, 0.0, 0.9));
    return vec4(c, clamp(v, 0.0, 1.0) * strength);
}

// ---------------------------------------------------------------- ring

vec4 wfx_ring(vec2 q, vec3 p, float strength) {
    int b = int(round(p.b * 255.0));
    vec3 col = WFX_PAL[b & 31];
    float r = length(q);
    if (r > 1.0) {
        return vec4(0.0);
    }
    float th = atan(q.y, q.x);
    float r0 = 0.93;
    float w = 0.008 + 0.06 * p.r;
    float x = (r - r0) / w;
    float crest = exp(-x * x);
    float inside = step(r, r0);
    // the wake behind the crest: a wave packet's ripples dying away inward
    float wake = inside * exp((r - r0) / (w * 3.0)) * (0.55 + 0.45 * cos((r - r0) / w * 2.6)) * 0.2;
    float pool = p.g * inside * smoothstep(r0, 0.0, r) * 0.22;
    float grain = 0.75 + 0.25 * wfx_noise(vec2((th / WFX_TAU + 0.5) * 48.0, r * 18.0), vec2(48.0, 1e4));
    float edge = 1.0 - smoothstep(0.985, 1.0, r);
    float v = ((crest * 1.2 + wake) * grain + pool) * edge;
    vec3 c = mix(col, vec3(1.0), clamp(crest * 0.8, 0.0, 1.0));
    return vec4(c, clamp(v, 0.0, 1.0) * strength);
}

// ---------------------------------------------------------------- beam

vec4 wfx_beam(vec2 q, vec3 p, float phase) {
    int b = int(round(p.b * 255.0));
    vec3 col = WFX_PAL[b & 31];
    float x = q.x;
    float y = q.y * 0.5 + 0.5;
    float core = exp(-pow(x / 0.10, 2.0));
    float glow = exp(-abs(x) / 0.18) * 0.35;
    float wide = exp(-x * x / 0.30) * 0.07;
    // streaks rising: noise that wraps every 8 cells up, run up 8 cells a period, so phase 1 = phase 0
    float s = wfx_noise(vec2(x * 9.0 + 40.0, y * 8.0 - phase * 8.0), vec2(1e4, 8.0));
    float s2 = wfx_noise(vec2(x * 23.0 + 11.0, y * 16.0 - phase * 16.0), vec2(1e4, 16.0));
    float streaks = pow(s, 3.0) * 1.2 + pow(s2, 4.0) * 0.8;
    float body = core * 1.3 + (glow + wide) * (0.55 + 0.6 * streaks);
    // a helix round it, two strands, the back one dimmer
    float helix = 0.0;
    if (p.g > 0.01) {
        for (int k = 0; k < 2; k++) {
            float a = WFX_TAU * (y * 5.0 - phase * 2.0) + float(k) * 3.14159;
            float hx = 0.42 * sin(a);
            float front = cos(a) > 0.0 ? 1.0 : 0.35;
            helix += exp(-pow((x - hx) / 0.035, 2.0)) * front;
        }
        helix *= p.g;
    }
    float foot = smoothstep(0.0, 0.06, y);
    float top = pow(1.0 - y, 1.3);
    float v = (body + helix) * foot * top * (1.0 - smoothstep(0.9, 1.0, abs(x)));
    vec3 c = mix(col, vec3(1.0), clamp(core * 0.9 + helix * 0.3, 0.0, 1.0));
    return vec4(c, clamp(v, 0.0, 1.0) * p.r);
}

// ---------------------------------------------------------------- nova

vec4 wfx_nova(vec2 q, vec3 p, float prog) {
    float r = length(q);
    if (r > 1.0) {
        return vec4(0.0);
    }
    float th = atan(q.y, q.x);
    float e = 1.0 - pow(1.0 - prog, 3.0);
    float R = 0.08 + 0.84 * e;
    float w = 0.012 + 0.05 * prog;
    float fade = 1.0 - smoothstep(0.55, 1.0, prog);
    // the shell, split a little by colour at its edge
    vec3 shell = vec3(exp(-pow((r - R * 1.012) / w, 2.0)), exp(-pow((r - R) / w, 2.0)), exp(-pow((r - R * 0.988) / w, 2.0)));
    float inner = smoothstep(R, 0.0, r) * 0.30 * fade;
    float flash = exp(-r * r / (0.01 + 0.25 * (1.0 - prog))) * pow(1.0 - prog, 2.0) * 2.0;
    // twelve rays, one per element, turning as they run out
    float spin = prog * 0.9;
    float sector = floor(fract((th - spin) / WFX_TAU + 0.5 / 12.0) * 12.0);
    float ray = pow(abs(cos(6.0 * (th - spin))), 90.0) * exp(-r / (0.25 + 0.5 * e)) * p.g * (1.0 - prog);
    vec3 rayCol = WFX_PAL[16 + int(mod(sector, 12.0))];
    float sparkle = step(0.985, wfx_hash(floor(vec2(th * 40.0, r * 60.0)))) * exp(-pow((r - R) / (w * 3.0), 2.0)) * fade;
    vec3 base = WFX_PAL[int(round(p.b * 255.0)) & 31];
    vec3 c = shell * (0.8 + 0.4 * base) * fade * 1.4 + base * inner + vec3(flash) + rayCol * ray * 1.5 + vec3(sparkle);
    float a = clamp(max(max(c.r, c.g), c.b), 0.0, 1.0);
    float edge = 1.0 - smoothstep(0.96, 1.0, r);
    return vec4(c / max(a, 1e-3), a * p.r * edge);
}

// ---------------------------------------------------------------- seam

/**
 * The seam: an almond of light, not a line (a bright jagged line reads as lightning). Its lips are the
 * profile w(y) = (0.02 + 0.30·open)·sin(πy)^0.75 swaying a little with the phase; outside them light
 * leaks out, e^(−d/λ); inside, once it opens, is the void with violet streams drawn up through it.
 */
vec4 wfx_seam(vec2 q, vec3 p, float phase) {
    int b = int(round(p.b * 255.0));
    vec3 col = WFX_PAL[b & 31];
    float open = p.r;
    float y = q.y * 0.5 + 0.5;
    float lens = pow(max(sin(3.14159 * y), 0.0), 0.75);
    float w = (0.02 + 0.30 * open) * lens;
    float sway = 0.015 * sin(y * 6.0 + phase * WFX_TAU) * (1.0 - 0.5 * open);
    float x = q.x - sway;
    float d = abs(x) - w;
    float rim = exp(-pow(d / (0.012 + 0.02 * open), 2.0)) * lens;
    float aura = exp(-max(d, 0.0) / (0.04 + 0.06 * open)) * lens * 0.3;
    float inside = smoothstep(0.0, -0.03, d) * smoothstep(0.08, 0.4, open);
    float streams = pow(wfx_noise(vec2(x * 14.0 + 5.0, y * 6.0 - phase * 6.0), vec2(1e4, 6.0)), 3.0);
    vec3 voidCol = mix(vec3(0.02, 0.0, 0.05), col * 0.8, streams * 0.6);
    float shimmer = 0.85 + 0.15 * wfx_noise(vec2(y * 24.0 - phase * 24.0, 1.0), vec2(24.0, 1e4));
    vec3 c = mix(col, vec3(1.0), clamp(rim * 0.85, 0.0, 1.0));
    float a = (rim * 1.3 + aura) * shimmer;
    c = mix(c, voidCol, inside);
    a = max(a, inside * 0.92);
    float edge = (1.0 - smoothstep(0.75, 1.0, abs(q.x))) * (1.0 - smoothstep(0.92, 1.0, abs(q.y)));
    return vec4(c, clamp(a, 0.0, 1.0) * p.g * edge);
}

// ---------------------------------------------------------------- lens

/**
 * The Proctor (Surge Trials, surgepack v30): a glass eye in a black housing that looks at things.
 *
 * r and g are a gaze in the WORLD (yaw r·2π from +z toward +x, pitch (g − 0.5)·π, up positive). The
 * vertex shader turns it into view space (fxGaze) with the camera's own turn, and the display is a
 * centre billboard, so q is already view x/y: the glass is the hemisphere n = (q/R, √(1 − |q/R|²))
 * facing the viewer, and the iris is wherever n is within IRIS of the gaze. Every viewer sees the eye
 * looking at the same place, from their own side; a gaze turned away from you hides the iris behind
 * the glass, the way a real eye would.
 *
 * a is a phase 0..1 (a sawtooth the plugin runs): the housing's twenty plates and the iris blades turn
 * with it, and a faint scan line runs down the glass. Variant 1 is the alert eye (red iris).
 */
vec4 wfx_lens(vec2 q, vec3 p, float phase, vec3 gaze) {
    int b = int(round(p.b * 255.0));
    vec3 pupilCol = WFX_PAL[b & 31];
    int variant = b >> 5;
    float r = length(q);
    if (r > 1.0) {
        return vec4(0.0);
    }
    float spin = phase * WFX_TAU;
    const float R = 0.78;
    vec2 light = normalize(vec2(-0.55, 0.83));

    if (r > R) {
        // the housing: twenty dark plates with seams, a bevel lit from the top left, a lit inner lip
        float th = atan(q.y, q.x);
        float plate = fract((th - spin) / WFX_TAU * 20.0);
        float seam = smoothstep(0.0, 0.05, plate) * smoothstep(1.0, 0.95, plate);
        float lit = 0.5 + 0.5 * dot(q / max(r, 1e-4), light);
        float t = (r - R) / (1.0 - R);
        float bevel = 0.6 + 0.4 * sin(t * 3.14159);
        vec3 metal = vec3(0.05, 0.055, 0.065) * (0.45 + 0.9 * lit) * bevel * (0.5 + 0.5 * seam);
        float lip = exp(-pow((r - 0.968) / 0.007, 2.0)) * (0.25 + 0.75 * lit);
        float inner = exp(-pow((r - R - 0.006) / 0.007, 2.0));
        vec3 innerCol = variant == 1 ? vec3(1.0, 0.3, 0.25) : vec3(0.6, 0.95, 1.0);
        metal += vec3(0.8, 0.84, 0.9) * lip * 0.4 + innerCol * inner * 0.8;
        return vec4(metal, 1.0 - smoothstep(0.985, 1.0, r));
    }

    vec2 s = q / R;
    float z = sqrt(max(1.0 - dot(s, s), 0.0));
    vec3 n = vec3(s, z);
    // dark glass, a cold fresnel rim
    vec3 c = vec3(0.015, 0.02, 0.03) + vec3(0.30, 0.50, 0.62) * pow(1.0 - z, 3.0) * 0.7;

    float ang = acos(clamp(dot(n, gaze), -1.0, 1.0));
    float aa = max(fwidth(ang), 1e-3);
    const float IRIS = 0.62;
    float pupil = variant == 1 ? 0.24 : 0.17;
    if (ang < IRIS + aa) {
        // a frame on the iris: the angle round the gaze, for blades and striations
        vec3 up = abs(gaze.y) < 0.95 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
        vec3 t1 = normalize(cross(up, gaze));
        vec3 t2 = cross(gaze, t1);
        float around = atan(dot(n, t2), dot(n, t1));
        float rr = ang / IRIS;
        // nine aperture blades, curved, turning with the phase
        float blade = fract((around + spin * 0.5 + rr * 1.8) / WFX_TAU * 9.0);
        float edge = smoothstep(0.0, 0.06, blade) * smoothstep(1.0, 0.9, blade);
        float stria = 0.75 + 0.25 * wfx_noise(vec2((around / WFX_TAU + 0.5) * 64.0, rr * 3.0), vec2(64.0, 1e4));
        vec3 irisCol = variant == 1 ? vec3(1.0, 0.32, 0.25) : vec3(0.72, 0.96, 1.0);
        float glow = mix(1.25, 0.55, rr) * stria * (0.6 + 0.4 * edge);
        vec3 iris = irisCol * glow;
        // the dark limbal ring at the iris edge
        iris *= 1.0 - 0.75 * smoothstep(0.78, 0.98, rr);
        float inIris = 1.0 - smoothstep(IRIS - aa, IRIS + aa, ang);
        c = mix(c, iris, inIris);
        // the pupil: the colour from b, white-hot in the middle
        float inPupil = 1.0 - smoothstep(pupil - aa, pupil + aa, ang);
        vec3 hot = mix(pupilCol * 1.3, vec3(1.0, 0.92, 0.9), exp(-pow(ang / (pupil * 0.45), 2.0)));
        c = mix(c, hot, inPupil);
        c += pupilCol * exp(-pow((ang - pupil) / 0.05, 2.0)) * 0.5 * (1.0 - inPupil);
    }

    // a scan line running down the glass, and the window highlight (fixed in view space)
    float scanY = 1.0 - 2.0 * fract(phase * 4.0);
    c += vec3(0.4, 0.8, 1.0) * exp(-pow((s.y - scanY) / 0.025, 2.0)) * 0.12 * z;
    vec2 hl = s - vec2(-0.38, 0.45);
    c += vec3(1.0) * exp(-dot(hl, hl) / 0.012) * 0.85 + vec3(1.0) * exp(-dot(hl, hl) / 0.08) * 0.08;
    return vec4(c, 1.0);
}

/** Kind 20..25 (key 50..55) at the quad's own q, with the glyph's colour as its parameters. */
vec4 wfx(int kind, vec2 q, vec4 params) {
    float smooth01 = wfx_smooth(params.a);
    vec3 p = params.rgb;
    if (kind == 20) {
        return wfx_halo(q, p, smooth01);
    } else if (kind == 21) {
        return wfx_sigil(q, p, smooth01);
    } else if (kind == 22) {
        return wfx_ring(q, p, smooth01);
    } else if (kind == 23) {
        return wfx_beam(q, p, smooth01);
    } else if (kind == 24) {
        return wfx_nova(q, p, smooth01);
    }
    return wfx_seam(q, p, smooth01);
}

#endif
