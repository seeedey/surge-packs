#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:surge_border.glsl>

// Vanilla 1.21.11 rendertype_world_border.fsh, with the wall drawn by surge_border.glsl (surgepack v22).
// The vanilla stripes stay underneath at a fifth of their light, so the wall still reads as the border.

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec3 wallPos;
in float wallClock;
in float eyeY;

out vec4 fragColor;

void main() {
    vec4 stripes = texture(Sampler0, texCoord0);
    vec4 wall = sb_wall(wallPos, wallClock, eyeY, ColorModulator.rgb);
    float a = clamp(wall.a + stripes.a * 0.2, 0.0, 1.0) * ColorModulator.a;
    if (a <= 0.002) {
        discard;
    }
    vec3 col = (wall.rgb * wall.a + ColorModulator.rgb * stripes.a * 0.2) / max(wall.a + stripes.a * 0.2, 1e-3);
    fragColor = vec4(col, a);
}
