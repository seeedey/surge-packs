#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:surge_opening_data.glsl>
#moj_import <minecraft:surge_world_warp.glsl>

// Vanilla 1.21.11 terrain.vsh, plus the Season 2 opening's world warp (surge_world_warp.glsl). Outside
// the warp's fog signal this is vanilla exactly.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec4 minecraft_sample_lightmap(sampler2D lightMap, ivec2 uv) {
    return texture(lightMap, clamp((uv / 256.0) + 0.5 / 16.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0)));
}

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    float phase = ww_phase(FogEnvironmentalEnd);
    if (phase >= 0.0) {
        // camera-relative -> world (exact enough: the stage is near the origin), warp, and back
        vec3 camera = vec3(CameraBlockPos) - CameraOffset;
        pos = ww_warp(pos + camera, phase, GameTime * 24000.0) - camera;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
