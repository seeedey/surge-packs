#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// Vanilla 1.21.11 rendertype_text.vsh, plus Surge's fullscreen effects. Written for surgepack v19 to
// replace the third-party text shader; every glyph that is not one of ours is drawn exactly as vanilla.
//
// HOW AN EFFECT GETS ON SCREEN. The plugin sends a title made of glyphs from overlays:fx (and the old
// overlays:fullscreen_*). Each of those glyphs is a solid block of one KEY colour that no real glyph
// uses. This shader samples the glyph's own texture; a key colour turns the glyph's quad into the whole
// screen, and the glyph's text colour carries the effect's three parameters (r, g, b, 0..255 each).
// The text pipeline gets no Globals block, so there is no GameTime here: anything that moves is moved
// by the plugin sending new parameters every tick.
//
// Keys (texture rgb):  215 40 255  tint       (the old Overlay.flash sheet, e800)
//                      215 41 255  bloom      r strength, g progress, b palette | phase << 4
//                      215 42 255  vignette   r strength, g pulse,    b palette | phase << 4
//                      215 43 255  crack      r strength, g opening,  b palette | seed << 3
//                      215 44 255  letterbox  r bar size
//
// Which corner of the screen a vertex goes to comes from the glyph's vertex order, which is fixed in
// 1.21.11: top-left, bottom-left, bottom-right, top-right, four vertices to a glyph. The same order says
// which way is into the glyph, so the key is sampled a texel and a half in from the vertex's own UV.
// (Reading the corner off the texture instead cannot work: the atlas packs glyphs edge to edge, and a
// sample stepping out of one key glyph lands in the next at the same offset it would have going in.)
//
// Gold (#FFD700) text, which the old shader drew with a shimmer, gets a vertical gold gradient.
//
// WORLD EFFECTS (surgepack v22). A glyph from overlays:world on a text display in the world keys
// 215 50..56 255 (56, the Trials lens, since v30). Its quad stays where the display put it (so the display's own interpolated scale,
// turn and billboard move it smoothly), fxPos says where in the quad a vertex is, and
// surge_world_fx.glsl draws the effect. Glows that stand up (halo, beam, nova, seam) are pushed back
// along the view ray by a little (at most 15% of the distance): the quad lands on screen exactly where
// it was, but behind what stands in its light, so the depth it writes does not hide those particles.

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out int fxKind;
out vec2 fxPos;
flat out vec4 fxParams;
flat out float fxAspect;
flat out vec3 fxGaze;

// Per vertex of a glyph: where it goes on screen, and which way (in UV) is into the glyph.
const vec2 CORNER[4] = vec2[](vec2(-1.0, 1.0), vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0));
const vec2 INWARD[4] = vec2[](vec2(1.0, 1.0), vec2(1.0, -1.0), vec2(-1.0, -1.0), vec2(-1.0, 1.0));

int keyAt(vec2 uv) {
    vec4 c = textureLod(Sampler0, uv, 0.0);
    if (c.a < 0.99) {
        return 0;
    }
    ivec3 k = ivec3(round(c.rgb * 255.0));
    if (k.r != 215 || k.b != 255) {
        return 0;
    }
    if (k.g >= 40 && k.g <= 44) {
        return k.g - 39;
    }
    if (k.g >= 50 && k.g <= 56) {
        return k.g - 30;          // 20..25: world effects
    }
    return 0;
}

/** How far a standing glow is pushed back along the view ray, in blocks, before the 15% cap. */
float worldPush(int kind) {
    return kind == 20 ? 1.5 : (kind == 23 ? 0.6 : (kind == 24 ? 5.0 : (kind == 25 ? 0.4 : 0.0)));
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    fxKind = 0;
    fxPos = vec2(0.0);
    fxParams = Color;
    fxAspect = 1.0;
    fxGaze = vec3(0.0, 0.0, 1.0);

    // Only GUI glyphs pushed thousands of units down by a huge negative ascent can be ours; a sign or
    // a text display in the world never is, whatever it prints.
    if (Position.y > 2000.0 && Color.a > 0.02) {
        vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
        int v = gl_VertexID % 4;
        int key = keyAt(UV0 + INWARD[v] * texel * 1.5);
        if (key > 0 && key < 20) {
            fxKind = key;
            gl_Position = vec4(CORNER[v], 0.0, 1.0);
            fxPos = CORNER[v];
            float sx = abs(ProjMat[0][0]);
            float sy = abs(ProjMat[1][1]);
            fxAspect = sx > 0.0 ? sy / sx : 16.0 / 9.0;
        }
    }

    // World effects: a glyph from overlays:world, anywhere but the GUI's far-down effect strip.
    if (fxKind == 0 && Position.y <= 2000.0) {
        vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
        int v = gl_VertexID % 4;
        int key = keyAt(UV0 + INWARD[v] * texel * 1.5);
        if (key >= 20) {
            fxKind = key;
            fxPos = CORNER[v];
            vec4 view = ModelViewMat * vec4(Position, 1.0);
            float d = length(view.xyz);
            float push = min(d * 0.15, worldPush(key));
            if (push > 0.0 && d > 0.01) {
                view.xyz *= (d + push) / d;
            }
            gl_Position = ProjMat * view;
        if (key == 26) {
            // the lens: its world gaze (r yaw, g pitch) into view space, the camera's own turn
            float yaw = Color.r * 6.28318531;
            float pitch = (Color.g - 0.5) * 3.14159265;
            vec3 dir = vec3(sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch));
            fxGaze = normalize(mat3(ModelViewMat) * dir);
        }
        }
    }

    // Gold names and lore, not their shadows (a shadow is the colour at a quarter).
    if (fxKind == 0) {
        ivec3 c = ivec3(round(Color.rgb * 255.0));
        if (c == ivec3(255, 215, 0)) {
            fxKind = 9;
            int corner = gl_VertexID % 4;
            fxPos = vec2(corner >= 2 ? 1.0 : 0.0, (corner == 1 || corner == 2) ? 1.0 : 0.0);
        }
    }
}
