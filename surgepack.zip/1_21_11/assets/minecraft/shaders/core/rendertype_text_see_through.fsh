#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:surge_world_fx.glsl>

// Vanilla 1.21.11 rendertype_text_see_through.fsh, plus Surge's world effects (see the .vsh).

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;
flat in int fxKind;
in vec2 fxPos;
flat in vec4 fxParams;

out vec4 fragColor;

void main() {
    if (fxKind >= 20) {
        vec4 w = wfx(fxKind, fxPos, fxParams) * ColorModulator;
        if (w.a < 0.004) {
            discard;
        }
        fragColor = w;
        return;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color * ColorModulator;
}
