#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:surge_opening_data.glsl>
#moj_import <minecraft:surge_opening_sky.glsl>

// Vanilla 1.21.11 sky.fsh, plus the Season 2 opening's sky. Outside the opening this is vanilla exactly.

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec3 skyPos;

out vec4 fragColor;

void main() {
    if (!os_active(ColorModulator)) {
        fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
        return;
    }
    fragColor = vec4(os_sky(normalize(skyPos), ColorModulator), ColorModulator.a);
}
