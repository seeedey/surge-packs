#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:surge_opening_data.glsl>
#moj_import <minecraft:surge_opening_sky.glsl>

// Vanilla 1.21.11 sky.vsh, plus the Season 2 opening's sky. Outside the opening this is vanilla exactly.

in vec3 Position;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec3 skyPos;

void main() {
    vec3 pos = Position;
    // While the opening runs, the top disc's rim is pulled down below the horizon, which turns the
    // disc into a cone, so the storm runs on down behind the hills. The fragment shader works from
    // direction alone, so the cone's facets never show. The dark disc under the world (y = -16) stays.
    if (os_active(ColorModulator) && pos.y > 0.0 && length(pos.xz) > 1.0) {
        pos.y = -256.0;
    }
    skyPos = pos;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
}
