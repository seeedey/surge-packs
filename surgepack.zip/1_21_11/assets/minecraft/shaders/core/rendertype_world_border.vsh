#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// Vanilla 1.21.11 rendertype_world_border.vsh, plus what surge_border.glsl needs to draw the wall itself
// (surgepack v22): where on the wall a point is, in blocks, and the wall's own clock.
//
// What the game feeds this pass (WorldBorderRendering.render, checked against the 1.21.11 jar):
//   Position     the wall's vertex, x and z from the border's west and north bounds, y the world's
//   ModelOffset  (west - camera x, -camera y, north - camera z)
//   TextureMat   a translation (f, f) with f = (milliseconds % 3000) / 3000: a clock with a 3 s period
//   ColorModulator  the border's stage colour (blue still, green growing, red shrinking), alpha the
//                   vanilla fade with the distance to the wall

in vec3 Position;
in vec2 UV0;

out vec2 texCoord0;
out vec3 wallPos;
out float wallClock;
out float eyeY;

void main() {
    vec3 pos = Position + ModelOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    wallPos = Position;
    wallClock = TextureMat[3][0];
    eyeY = -ModelOffset.y;
}
