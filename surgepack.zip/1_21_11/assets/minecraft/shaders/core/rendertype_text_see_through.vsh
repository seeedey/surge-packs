#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

// Vanilla 1.21.11 rendertype_text_see_through.vsh, plus Surge's world effects (surgepack v22). A text
// display with see_through set is drawn here, with no depth test and no depth write: the plugin uses
// that for light nothing should hide, the supernova. Key detection and corners are as in
// rendertype_text.vsh; the effect is drawn by surge_world_fx.glsl. Every other glyph is vanilla.

in vec3 Position;
in vec4 Color;
in vec2 UV0;

uniform sampler2D Sampler0;

out vec4 vertexColor;
out vec2 texCoord0;
flat out int fxKind;
out vec2 fxPos;
flat out vec4 fxParams;

const vec2 CORNER[4] = vec2[](vec2(-1.0, 1.0), vec2(-1.0, -1.0), vec2(1.0, -1.0), vec2(1.0, 1.0));
const vec2 INWARD[4] = vec2[](vec2(1.0, 1.0), vec2(1.0, -1.0), vec2(-1.0, -1.0), vec2(-1.0, 1.0));

int worldKeyAt(vec2 uv) {
    vec4 c = textureLod(Sampler0, uv, 0.0);
    if (c.a < 0.99) {
        return 0;
    }
    ivec3 k = ivec3(round(c.rgb * 255.0));
    if (k.r != 215 || k.b != 255 || k.g < 50 || k.g > 55) {
        return 0;
    }
    return k.g - 30;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    texCoord0 = UV0;
    fxKind = 0;
    fxPos = vec2(0.0);
    fxParams = Color;

    vec2 texel = 1.0 / vec2(textureSize(Sampler0, 0));
    int v = gl_VertexID % 4;
    int key = worldKeyAt(UV0 + INWARD[v] * texel * 1.5);
    if (key >= 20) {
        fxKind = key;
        fxPos = CORNER[v];
    }
}
