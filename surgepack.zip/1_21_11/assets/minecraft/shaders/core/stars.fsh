#version 330

#moj_import <minecraft:dynamictransforms.glsl>

// Vanilla 1.21.11 stars.fsh, plus the streaks from stars.vsh fading from head to tail.

in float starTail;

out vec4 fragColor;

void main() {
    if (ColorModulator.a <= 0.52) {
        fragColor = ColorModulator;
        return;
    }
    float lit = min(ColorModulator.a, 1.0);
    fragColor = vec4(vec3(lit), lit * mix(1.0, 0.1, starTail));
}
