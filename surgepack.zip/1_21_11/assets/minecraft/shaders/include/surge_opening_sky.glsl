#version 330

// The Season 2 opening's sky: reading the clock out of the sky colour, and drawing the sky it says.
//
// Import after fog.glsl, dynamictransforms.glsl and surge_opening_data.glsl. The sky pipeline binds
// DynamicTransforms, Projection and Fog and nothing else, so GameTime never reaches it; the only time
// this knows is the one the timeline writes into the sky colour, twenty times a second (and the game
// interpolates between ticks, so it moves smoothly).
//
// Layers, each a formula of direction d and time:
//   storm      elevation gradient + 3-octave fbm clouds drifting on a slow rotation
//   memories   a tint per act, each windowed by smootherstep in and out:
//                day one   a white point ahead of her that swells and bursts into 24 rays
//                revival   soul blue, four comets on great circles from the four quarters to the zenith
//                knight    steel, one sheet of cloud lightning at the bolt
//                crowns    the sky split gold (her left, the King) against lavender (her right, the
//                          server); the split line swings over to his side as the front runs, and
//                          the gold is wiped out at contact
//                cost      bruised dark, the seam widens
//                grant     twelve element colours as aurora curtains: height h(az) = sum of three
//                          sines, brightness exp(-(e - h)^2/w^2) striped by a high-frequency sine
//   seam       a great circle through the zenith along FWD, displaced by a sum of triangle waves
//              so it is jagged; its width is a schedule
//   rip        (the tear) Voronoi plates of sky on either side of the seam fall away by hash and
//              distance, the void behind them shows, their edges burn
//   close      plates back, a white stitch along the seam, then dawn from the east
//
// tools/opening-preview.py renders this with moderngl from the same files; keep it compiling there.

// ---------------------------------------------------------------- the signal

bool os_active(vec4 sky) {
    vec3 c = sky.rgb * 255.0;
    return abs(c.r - OS_MARK_R) < 1.5 && c.g < OS_SEG + 1.5 && c.b < OS_B_MAX + 2.5;
}

// Ticks since the window's first keyframe, fractional between ticks.
float os_ticks(vec4 sky) {
    vec3 c = sky.rgb * 255.0;
    float segment = floor(c.b / OS_B_STEP + 0.5);
    float k = c.g;
    if (mod(segment, 2.0) > 0.5) {
        k = OS_SEG - 1.0 - k;
    }
    return segment * OS_SEG + clamp(k, 0.0, OS_SEG - 1.0);
}

// ---------------------------------------------------------------- noise

uvec3 os_pcg(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z;
    v.y += v.z * v.x;
    v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z;
    v.y += v.z * v.x;
    v.z += v.x * v.y;
    return v;
}

vec3 os_hash3(vec3 p) {
    return vec3(os_pcg(uvec3(ivec3(floor(p)) + 4096))) * (1.0 / 4294967295.0);
}

float os_hash(vec3 p) {
    return os_hash3(p).x;
}

float os_noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float x00 = mix(os_hash(i), os_hash(i + vec3(1, 0, 0)), u.x);
    float x10 = mix(os_hash(i + vec3(0, 1, 0)), os_hash(i + vec3(1, 1, 0)), u.x);
    float x01 = mix(os_hash(i + vec3(0, 0, 1)), os_hash(i + vec3(1, 0, 1)), u.x);
    float x11 = mix(os_hash(i + vec3(0, 1, 1)), os_hash(i + vec3(1, 1, 1)), u.x);
    return mix(mix(x00, x10, u.y), mix(x01, x11, u.y), u.z);
}

float os_fbm(vec3 p) {
    float sum = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 3; i++) {
        sum += amp * os_noise(p);
        p = p * 2.03 + vec3(11.7, 5.3, 2.9);
        amp *= 0.5;
    }
    return sum / 0.875;
}

// Smootherstep window: 0 before a, up over `rise`, held, down over `fall` after b.
float os_window(float t, float a, float rise, float b, float fall) {
    float up = clamp((t - a) / max(rise, 1e-3), 0.0, 1.0);
    float down = clamp((b - t) / max(fall, 1e-3), 0.0, 1.0);
    up = up * up * up * (up * (up * 6.0 - 15.0) + 10.0);
    down = down * down * down * (down * (down * 6.0 - 15.0) + 10.0);
    return min(up, down);
}

float os_tri(float x) {
    return abs(fract(x) - 0.5) * 4.0 - 1.0;
}

// The seam's jag: a sum of triangle waves along the arc, a, in radians.
float os_jag(float a, float seed) {
    return 0.020 * os_tri(a * 3.1 + seed) + 0.011 * os_tri(a * 7.9 + seed * 1.7) + 0.005 * os_tri(a * 19.3 - seed);
}

// Voronoi on the sphere of directions: x = distance to the nearest edge, y = that cell's hash.
vec2 os_plates(vec3 p) {
    vec3 cell = floor(p);
    float best = 9.0;
    float second = 9.0;
    vec3 bestCell = cell;
    for (int z = -1; z <= 1; z++) {
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                vec3 c = cell + vec3(x, y, z);
                float dist = length(c + os_hash3(c) - p);
                if (dist < best) {
                    second = best;
                    best = dist;
                    bestCell = c;
                } else if (dist < second) {
                    second = dist;
                }
            }
        }
    }
    return vec2(second - best, os_hash(bestCell + 17.0));
}

// ---------------------------------------------------------------- the sky

const vec3 OS_GOLD = vec3(0.95, 0.70, 0.35);
const vec3 OS_LAVENDER = vec3(0.73, 0.66, 1.00);
const vec3 OS_PALE = vec3(0.95, 0.93, 1.00);
const vec3 OS_SOUL = vec3(0.35, 0.80, 0.95);
const vec3 OS_STEEL = vec3(0.50, 0.56, 0.68);
const vec3 OS_SOULS[4] = vec3[](vec3(1.0, 0.48, 0.18), vec3(0.18, 0.77, 0.84), vec3(0.55, 0.75, 0.35), vec3(0.96, 0.90, 0.39));

// The real noon sky, near enough, so the first and last frames meet the game's own.
const vec3 OS_NOON_ZEN = vec3(0.47, 0.65, 1.00);
const vec3 OS_NOON_HOR = vec3(0.70, 0.82, 1.00);

vec3 os_storm(vec3 d, float t) {
    float e = d.y;
    vec3 zen = vec3(0.045, 0.025, 0.10);
    vec3 hor = vec3(0.20, 0.11, 0.32);
    vec3 col = mix(hor, zen, smoothstep(-0.05, 0.75, e));
    // clouds on a slow turn round the vertical
    float a = t * 0.004;
    vec3 q = vec3(d.x * cos(a) - d.z * sin(a), d.y, d.x * sin(a) + d.z * cos(a));
    float c = os_fbm(q * vec3(3.2, 5.0, 3.2) + vec3(0.0, -t * 0.015, 0.0));
    float billow = smoothstep(0.35, 0.85, c);
    col = mix(col, vec3(0.10, 0.06, 0.17), billow * 0.65);
    col += vec3(0.30, 0.16, 0.45) * pow(max(c - 0.55, 0.0), 2.0) * 1.6 * smoothstep(-0.1, 0.4, e);
    return col;
}

// Brightness of a comet head moving along the great circle from `from` to `to`, at u 0..1, with a tail.
float os_comet(vec3 d, vec3 from, vec3 to, float u) {
    if (u <= 0.0 || u >= 1.05) {
        return 0.0;
    }
    float omega = acos(clamp(dot(from, to), -1.0, 1.0));
    float s = sin(omega);
    float best = 0.0;
    for (int k = 0; k < 8; k++) {
        float uu = clamp(u - float(k) * 0.025, 0.0, 1.0);
        vec3 p = (sin((1.0 - uu) * omega) * from + sin(uu * omega) * to) / max(s, 1e-3);
        float dist = acos(clamp(dot(d, normalize(p)), -1.0, 1.0));
        float w = 0.018 + 0.008 * float(k);
        best = max(best, exp(-(dist * dist) / (w * w)) * (1.0 - float(k) / 8.0));
    }
    return best;
}

// Story time t (seconds of the opening). Returns the sky colour before the seam is drawn on.
vec3 os_story(vec3 d, float t) {
    vec3 col = os_storm(d, t);

    // the first five seconds: the real noon sky darkening into the storm
    float noon = 1.0 - os_window(t, 0.0, 5.0, 1e9, 1.0);
    if (noon > 0.0) {
        vec3 day = mix(OS_NOON_HOR, OS_NOON_ZEN, smoothstep(0.0, 0.6, d.y));
        col = mix(col, day, noon);
    }

    // ---- day one: a white point swells ahead of her and bursts
    float w1 = os_window(t, OS_ACT[2], 3.0, OS_ACT[3] + 1.0, 4.0);
    if (w1 > 0.0) {
        float rho = acos(clamp(dot(d, OS_DAY), -1.0, 1.0));
        float swell = os_window(t, OS_ACT[2] + 1.0, 8.0, OS_BURST, 0.3);
        col = mix(col, col + vec3(0.12, 0.11, 0.16), w1 * 0.6);
        col += OS_PALE * exp(-rho * rho / (0.004 + 0.02 * swell)) * swell * 1.4;
        float since = t - OS_BURST;
        if (since > 0.0) {
            float fade = exp(-since * 0.35);
            vec3 side = normalize(cross(OS_DAY, vec3(0.0, 1.0, 0.0)));
            vec3 up = cross(side, OS_DAY);
            float phi = atan(dot(d, up), dot(d, side));
            float rays = pow(max(cos(12.0 * phi), 0.0), 24.0) * smoothstep(0.0, 0.05, rho) * exp(-rho / (0.2 + since * 0.25));
            float ring = exp(-pow((rho - since * 0.35) / 0.05, 2.0));
            col += OS_PALE * (rays * 1.2 + ring * 0.8) * fade;
            col += OS_GOLD * exp(-rho * rho / 0.01) * os_window(t, OS_CROWN - 2.0, 1.0, OS_ACT[3], 2.0) * 0.8;
        }
    }

    // ---- the revival: soul blue, four comets home
    float w2 = os_window(t, OS_ACT[3], 3.0, OS_ACT[4], 3.0);
    if (w2 > 0.0) {
        col = mix(col, col * vec3(0.6, 1.1, 1.3) + OS_SOUL * 0.05, w2 * 0.7);
        float u = clamp((t - OS_SOULS_FROM) / (OS_SOULS_AT - OS_SOULS_FROM), 0.0, 1.1);
        for (int k = 0; k < 4; k++) {
            float a = 1.5707963 * float(k) + 0.7853982;
            vec3 from = normalize(vec3(cos(a), 0.06, sin(a)));
            col += OS_SOULS[k] * os_comet(d, from, vec3(0.0, 1.0, 0.0), u) * 1.6 * w2;
        }
        float arrive = exp(-max(t - OS_SOULS_AT, 0.0) * 1.2) * step(OS_SOULS_AT, t);
        col += OS_PALE * arrive * smoothstep(0.5, 1.0, d.y) * 0.9;
    }

    // ---- the knight: steel, and one sheet of lightning
    float w3 = os_window(t, OS_ACT[4], 3.0, OS_ACT[5], 3.0);
    if (w3 > 0.0) {
        float g = dot(col, vec3(0.3, 0.5, 0.2));
        col = mix(col, vec3(g) * OS_STEEL * 1.6, w3 * 0.55);
        float since = t - OS_BOLT;
        if (since > 0.0) {
            float sheet = exp(-since * 5.0) + 0.5 * exp(-max(since - 0.25, 0.0) * 7.0) * step(0.25, since);
            col += vec3(0.75, 0.80, 1.0) * sheet * pow(os_fbm(d * 4.0 + 3.0), 2.0) * 1.2;
        }
    }

    // ---- the crowns against the server: gold against lavender
    float w4 = os_window(t, OS_ACT[5], 4.0, OS_ACT[6], 4.0);
    if (w4 > 0.0) {
        float side = dot(d, OS_RIGHT);          // + server, - King
        float run = os_window(t, OS_FRONT, OS_CONTACT - OS_FRONT, 1e9, 1.0);
        float line = mix(0.0, -0.75, run);      // the split swings over to his side
        float wobble = 0.05 * sin(d.y * 9.0 + t * 1.3) + 0.03 * os_tri(dot(d, OS_FWD) * 4.0 + t * 0.2);
        float gold = 1.0 - smoothstep(line - 0.08, line + 0.08, side + wobble);
        float gone = os_window(t, OS_CONTACT, 0.4, 1e9, 1.0);
        gold *= 1.0 - gone;
        vec3 king = col * 0.7 + OS_GOLD * (0.06 + 0.45 * exp(-max(d.y, 0.0) * 4.0)) * (0.7 + 0.6 * os_fbm(d * 5.0 + t * 0.02));
        vec3 them = col * 0.8 + OS_LAVENDER * 0.16;
        col = mix(col, mix(them, king, gold), w4);
        float edge = exp(-pow((side + wobble - line) / 0.03, 2.0)) * (1.0 - gone);
        col += OS_PALE * edge * 0.7 * w4;
        float flash = exp(-max(t - OS_CONTACT, 0.0) * 2.5) * step(OS_CONTACT, t);
        col += OS_PALE * flash * 0.9 * w4;
    }

    // ---- what it cost: the storm bruises
    float w5 = os_window(t, OS_ACT[6], 4.0, OS_ACT[7], 3.0);
    col = mix(col, col * vec3(0.75, 0.45, 0.70), w5 * 0.6);

    // ---- the grant: aurora in every colour that can be handed out
    float w6 = os_window(t, OS_ACT[7] - 2.0, 5.0, OS_STORY + 4.0, 6.0);
    if (w6 > 0.0 && d.y > 0.02) {
        float az = atan(d.z, d.x);
        float e = asin(clamp(d.y, -1.0, 1.0));
        for (int k = 0; k < 3; k++) {
            float fk = float(k);
            float h = 0.55 + 0.12 * fk + 0.08 * sin(az * (2.0 + fk) + t * (0.25 + 0.1 * fk))
                    + 0.04 * sin(az * 7.0 - t * 0.6 + fk * 2.0) + 0.02 * sin(az * 13.0 + t * 1.1);
            // a sharp lower hem at h, fading up over a few tenths of a radian, striped by folds
            float curtain = smoothstep(h - 0.025, h, e) * exp(-max(e - h, 0.0) / (0.16 + 0.05 * fk));
            curtain *= 0.7 + 0.3 * sin(az * 34.0 + t * 0.8 + fk * 5.0 + 2.0 * sin(az * 5.0 + t * 0.3));
            curtain *= 1.1;
            float idx = fract(az / 6.2831853 + 0.5 + t * 0.01 + fk * 0.33) * 12.0;
            vec3 c = mix(OS_ELEMENT[int(idx) % 12], OS_ELEMENT[(int(idx) + 1) % 12], fract(idx));
            col += c * curtain * w6 * 0.9;
        }
    }
    return col;
}

// How open the seam is in story time: a hairline that wakes with her, widens as it costs her.
float os_seam_width(float t) {
    float w = 0.0015 * os_window(t, OS_ACT[1], 6.0, 1e9, 1.0);
    w += 0.004 * os_window(t, OS_CONTACT, 0.2, OS_CONTACT + 1.0, 2.0);
    w += 0.010 * os_window(t, OS_ACT[6] + 4.0, 20.0, 1e9, 1.0);
    w -= 0.006 * os_window(t, OS_ACT[7], 6.0, 1e9, 1.0);
    return max(w, 0.0);
}

// Distance (radians, roughly) from the seam, and where along it d is.
vec2 os_seam(vec3 d, float seed) {
    float along = atan(dot(d, OS_FWD), d.y);
    float off = asin(clamp(dot(d, OS_RIGHT), -1.0, 1.0));
    return vec2(abs(off - os_jag(along, seed)), along);
}

// The seam drawn as light: a white core and a lavender bloom.
vec3 os_draw_seam(vec3 col, float dist, float width, float boost) {
    if (width <= 0.0) {
        return col;
    }
    float core = exp(-pow(dist / max(width, 1e-4), 2.0));
    float bloom = exp(-dist / (width * 6.0 + 0.004));
    return col + OS_PALE * core * (1.2 + boost) + OS_LAVENDER * bloom * (0.35 + boost * 0.3);
}

// The rip: tr seconds into the tear (0..OS_TEAR, ping-pong), open 0..1 (the close sets it falling).
vec3 os_rip(vec3 d, float tr, vec3 col, float open) {
    vec2 seam = os_seam(d, 3.0);
    float band = 0.08 + 0.32 * open;
    if (seam.x < band + 0.12) {
        vec2 pl = os_plates(d * 7.0);
        float fall = 1.0 - smoothstep(0.0, band, seam.x + pl.y * 0.12 - open * 0.08);
        fall *= step(pl.y, 0.25 + 0.75 * open);
        // the void behind: near black, its own stars streaking, a violet glow welling up from the seam
        // what is behind the sky: black, a violet glow welling out of the seam, a nebula in it, and
        // its own stars drifting the other way
        vec3 vd = vec3(0.004, 0.0, 0.012);
        vd += vec3(0.55, 0.25, 0.95) * exp(-seam.x / (0.035 + 0.06 * open)) * (0.8 + 0.2 * sin(tr * 1.3));
        vd += vec3(0.25, 0.06, 0.35) * smoothstep(0.45, 0.9, os_fbm(d * 6.0 + vec3(tr * 0.05, 0.0, 0.0)));
        vec3 sp = d * 110.0;
        float star = step(0.982, os_hash(floor(sp + vec3(0.0, -tr * 0.8, 0.0))));
        vd += vec3(0.95, 0.9, 1.0) * star;
        col = mix(col, vd, fall);
        // the plates' torn edges burn white-violet, flickering
        float burn = exp(-pl.x / 0.015) * fall * (0.65 + 0.35 * sin(tr * 2.3 + pl.y * 40.0));
        float rim = exp(-abs(fall - 0.5) * 6.0) * step(0.02, fall) * (1.0 - step(0.98, fall));
        col += vec3(1.0, 0.88, 1.0) * burn * 1.1 + OS_LAVENDER * rim * 0.8;
    }
    return os_draw_seam(col, seam.x, 0.006 + 0.006 * open, 0.6 * open);
}

vec3 os_sky(vec3 d, vec4 sky) {
    float ticks = os_ticks(sky);
    float t = ticks / 20.0;
    if (t < OS_STORY) {
        vec3 col = os_story(d, t);
        return os_draw_seam(col, os_seam(d, 3.0).x, os_seam_width(t), 0.0);
    }
    float tr = t - OS_STORY;
    if (tr < OS_TEAR) {
        // the story's last sky, still settling, with the rip opening on it over four seconds
        vec3 col = os_story(d, OS_STORY + min(tr, 4.0));
        return os_rip(d, tr, col, os_window(tr, 0.0, 4.0, 1e9, 1.0));
    }
    float tc = tr - OS_TEAR;
    vec3 col = os_storm(d, OS_STORY + tc);
    float open = 1.0 - os_window(tc, 0.0, OS_HEAL - 1.0, 1e9, 1.0);
    col = os_rip(d, tc, col, open);
    // the stitch: one bright pass along the seam as it shuts
    float stitch = os_window(tc, OS_HEAL - 2.0, 1.0, OS_HEAL + 0.5, 1.5);
    col = os_draw_seam(col, os_seam(d, 3.0).x, 0.004 * stitch, 1.5 * stitch);
    // dawn from the east, then noon
    float dawn = os_window(tc, OS_HEAL, 6.0, 1e9, 1.0);
    if (dawn > 0.0) {
        float east = max(dot(normalize(vec3(d.x, 0.0, d.z) + 1e-4), vec3(1.0, 0.0, 0.0)), 0.0);
        vec3 low = mix(vec3(1.0, 0.62, 0.42), vec3(0.95, 0.55, 0.65), 1.0 - east);
        vec3 high = vec3(0.32, 0.45, 0.85);
        vec3 morning = mix(low, high, smoothstep(-0.1, 0.8, d.y));
        morning += vec3(1.0, 0.7, 0.45) * pow(east, 6.0) * exp(-max(d.y, 0.0) * 6.0) * 0.6;
        float noon = os_window(tc, OS_CLOSE - 10.0, 7.0, 1e9, 1.0);
        vec3 day = mix(OS_NOON_HOR, OS_NOON_ZEN, smoothstep(0.0, 0.6, d.y));
        col = mix(col, mix(morning, day, noon), dawn);
    }
    return col;
}
