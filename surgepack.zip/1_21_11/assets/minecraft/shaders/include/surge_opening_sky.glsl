#version 330

// The Season 2 opening's sky: reading the clock out of the sky colour, and drawing the sky it says.
//
// Import after fog.glsl, dynamictransforms.glsl and surge_opening_data.glsl. The sky pipeline binds
// DynamicTransforms, Projection and Fog and nothing else, so GameTime never reaches it; the only time
// this knows is the one the timeline writes into the sky colour, twenty times a second (and the game
// interpolates between ticks, so it moves smoothly).
//
// Layers, each a formula of direction d and time:
//   storm      elevation gradient + 3-octave fbm clouds drifting on a slow rotation
//   memories   a tint per act, each windowed by smootherstep in and out:
//                day one   a white point ahead of her that swells and bursts into 24 rays
//                revival   soul blue, four comets on great circles from the four quarters to the zenith
//                knight    steel, one sheet of cloud lightning at the bolt
//                crowns    the sky split gold (her left, the King) against lavender (her right, the
//                          server); the split line swings over to his side as the front runs, and
//                          the gold is wiped out at contact
//                cost      bruised dark, the seam widens
//                grant     twelve element colours as aurora curtains: height h(az) = sum of three
//                          sines, brightness exp(-(e - h)^2/w^2) striped by a high-frequency sine
//   climax     the build to her break: the storm turns faster, light gathers at the zenith; then
//              the sky whites out and fades back as the Surges land
//   rip        (the tear) Voronoi plates of sky either side of a great circle through the zenith
//              (along FWD, jagged by triangle waves) fall away by hash and distance; the void behind
//              them shows; their torn edges burn. No line is drawn along the circle itself.
//   close      plates back, then dawn from the east
//   made       (pack v21, rev 4) the world being made, in steps the plugin moves: see os_made below
//
// tools/opening-preview.py renders this with moderngl from the same files; keep it compiling there.

// ---------------------------------------------------------------- the signal

bool os_active(vec4 sky) {
    vec3 c = sky.rgb * 255.0;
    return abs(c.r - OS_MARK_R) < 1.5 && c.g < OS_SEG + 1.5 && c.b < OS_B_MAX + 2.5;
}

// Ticks since the window's first keyframe, fractional between ticks.
float os_ticks(vec4 sky) {
    vec3 c = sky.rgb * 255.0;
    float segment = floor(c.b / OS_B_STEP + 0.5);
    float k = c.g;
    if (mod(segment, 2.0) > 0.5) {
        k = OS_SEG - 1.0 - k;
    }
    return segment * OS_SEG + clamp(k, 0.0, OS_SEG - 1.0);
}

// ---------------------------------------------------------------- noise

uvec3 os_pcg(uvec3 v) {
    v = v * 1664525u + 1013904223u;
    v.x += v.y * v.z;
    v.y += v.z * v.x;
    v.z += v.x * v.y;
    v ^= v >> 16u;
    v.x += v.y * v.z;
    v.y += v.z * v.x;
    v.z += v.x * v.y;
    return v;
}

vec3 os_hash3(vec3 p) {
    return vec3(os_pcg(uvec3(ivec3(floor(p)) + 4096))) * (1.0 / 4294967295.0);
}

float os_hash(vec3 p) {
    return os_hash3(p).x;
}

float os_noise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float x00 = mix(os_hash(i), os_hash(i + vec3(1, 0, 0)), u.x);
    float x10 = mix(os_hash(i + vec3(0, 1, 0)), os_hash(i + vec3(1, 1, 0)), u.x);
    float x01 = mix(os_hash(i + vec3(0, 0, 1)), os_hash(i + vec3(1, 0, 1)), u.x);
    float x11 = mix(os_hash(i + vec3(0, 1, 1)), os_hash(i + vec3(1, 1, 1)), u.x);
    return mix(mix(x00, x10, u.y), mix(x01, x11, u.y), u.z);
}

float os_fbm(vec3 p) {
    float sum = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 3; i++) {
        sum += amp * os_noise(p);
        p = p * 2.03 + vec3(11.7, 5.3, 2.9);
        amp *= 0.5;
    }
    return sum / 0.875;
}

// Smootherstep window: 0 before a, up over `rise`, held, down over `fall` after b.
float os_window(float t, float a, float rise, float b, float fall) {
    float up = clamp((t - a) / max(rise, 1e-3), 0.0, 1.0);
    float down = clamp((b - t) / max(fall, 1e-3), 0.0, 1.0);
    up = up * up * up * (up * (up * 6.0 - 15.0) + 10.0);
    down = down * down * down * (down * (down * 6.0 - 15.0) + 10.0);
    return min(up, down);
}

float os_tri(float x) {
    return abs(fract(x) - 0.5) * 4.0 - 1.0;
}

// The seam's jag: a sum of triangle waves along the arc, a, in radians.
float os_jag(float a, float seed) {
    return 0.020 * os_tri(a * 3.1 + seed) + 0.011 * os_tri(a * 7.9 + seed * 1.7) + 0.005 * os_tri(a * 19.3 - seed);
}

// Voronoi on the sphere of directions: x = distance to the nearest edge, y = that cell's hash.
vec2 os_plates(vec3 p) {
    // organic, not cells: domain-warped fbm; x = closeness to its meandering mid-level contour, y = a smooth tone
    vec3 q = p + 0.9 * vec3(os_fbm(p * 0.6 + 3.1), os_fbm(p * 0.6 + 7.7), os_fbm(p * 0.6 + 1.3));
    float n = os_fbm(q);
    return vec2(abs(n - 0.5) * 0.9, os_noise(q * 0.4 + 5.0));
}

vec2 os_plates_voronoi(vec3 p) {
    vec3 cell = floor(p);
    float best = 9.0;
    float second = 9.0;
    vec3 bestCell = cell;
    for (int z = -1; z <= 1; z++) {
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                vec3 c = cell + vec3(x, y, z);
                float dist = length(c + os_hash3(c) - p);
                if (dist < best) {
                    second = best;
                    best = dist;
                    bestCell = c;
                } else if (dist < second) {
                    second = dist;
                }
            }
        }
    }
    return vec2(second - best, os_hash(bestCell + 17.0));
}

// ---------------------------------------------------------------- the sky

const vec3 OS_GOLD = vec3(0.95, 0.70, 0.35);
const vec3 OS_LAVENDER = vec3(0.73, 0.66, 1.00);
const vec3 OS_PALE = vec3(0.95, 0.93, 1.00);
const vec3 OS_SOUL = vec3(0.35, 0.80, 0.95);
const vec3 OS_STEEL = vec3(0.50, 0.56, 0.68);
const vec3 OS_SOULS[4] = vec3[](vec3(1.0, 0.48, 0.18), vec3(0.18, 0.77, 0.84), vec3(0.55, 0.75, 0.35), vec3(0.96, 0.90, 0.39));

// The real noon sky, near enough, so the first and last frames meet the game's own.
const vec3 OS_NOON_ZEN = vec3(0.47, 0.65, 1.00);
const vec3 OS_NOON_HOR = vec3(0.70, 0.82, 1.00);

vec3 os_storm(vec3 d, float t) {
    float e = d.y;
    vec3 zen = vec3(0.045, 0.025, 0.10);
    vec3 hor = vec3(0.20, 0.11, 0.32);
    vec3 col = mix(hor, zen, smoothstep(-0.05, 0.75, e));
    // clouds on a slow turn round the vertical
    float a = t * 0.004;
    vec3 q = vec3(d.x * cos(a) - d.z * sin(a), d.y, d.x * sin(a) + d.z * cos(a));
    float c = os_fbm(q * vec3(3.2, 5.0, 3.2) + vec3(0.0, -t * 0.015, 0.0));
    float billow = smoothstep(0.35, 0.85, c);
    col = mix(col, vec3(0.10, 0.06, 0.17), billow * 0.65);
    col += vec3(0.30, 0.16, 0.45) * pow(max(c - 0.55, 0.0), 2.0) * 1.6 * smoothstep(-0.1, 0.4, e);
    return col;
}

// Brightness of a comet head moving along the great circle from `from` to `to`, at u 0..1, with a tail.
float os_comet(vec3 d, vec3 from, vec3 to, float u) {
    if (u <= 0.0 || u >= 1.05) {
        return 0.0;
    }
    float omega = acos(clamp(dot(from, to), -1.0, 1.0));
    float s = sin(omega);
    float best = 0.0;
    for (int k = 0; k < 8; k++) {
        float uu = clamp(u - float(k) * 0.025, 0.0, 1.0);
        vec3 p = (sin((1.0 - uu) * omega) * from + sin(uu * omega) * to) / max(s, 1e-3);
        float dist = acos(clamp(dot(d, normalize(p)), -1.0, 1.0));
        float w = 0.018 + 0.008 * float(k);
        best = max(best, exp(-(dist * dist) / (w * w)) * (1.0 - float(k) / 8.0));
    }
    return best;
}

// Aurora in all twelve element colours: three curtains, height h(az) = sum of three sines, a sharp
// lower hem fading up over a few tenths of a radian, striped by folds.
vec3 os_aurora(vec3 d, float t) {
    vec3 col = vec3(0.0);
    if (d.y <= 0.02) {
        return col;
    }
    float az = atan(d.z, d.x);
    float e = asin(clamp(d.y, -1.0, 1.0));
    for (int k = 0; k < 3; k++) {
        float fk = float(k);
        float h = 0.55 + 0.12 * fk + 0.08 * sin(az * (2.0 + fk) + t * (0.25 + 0.1 * fk))
                + 0.04 * sin(az * 7.0 - t * 0.6 + fk * 2.0) + 0.02 * sin(az * 13.0 + t * 1.1);
        float curtain = smoothstep(h - 0.025, h, e) * exp(-max(e - h, 0.0) / (0.16 + 0.05 * fk));
        curtain *= 0.7 + 0.3 * sin(az * 34.0 + t * 0.8 + fk * 5.0 + 2.0 * sin(az * 5.0 + t * 0.3));
        curtain *= 1.1;
        float idx = fract(az / 6.2831853 + 0.5 + t * 0.01 + fk * 0.33) * 12.0;
        vec3 c = mix(OS_ELEMENT[int(idx) % 12], OS_ELEMENT[(int(idx) + 1) % 12], fract(idx));
        col += c * curtain;
    }
    return col;
}

// Story time t (seconds of the opening). Returns the sky colour before the seam is drawn on.
vec3 os_story(vec3 d, float t) {
    vec3 col = os_storm(d, t);

    // the first five seconds: the real noon sky darkening into the storm
    float noon = 1.0 - os_window(t, 0.0, 2.5, 1e9, 1.0);
    if (noon > 0.0) {
        vec3 day = mix(OS_NOON_HOR, OS_NOON_ZEN, smoothstep(0.0, 0.6, d.y));
        col = mix(col, day, noon);
    }

    // ---- day one: a white point swells ahead of her and bursts
    float w1 = os_window(t, OS_ACT[2], 0.8, OS_ACT[3] + 0.5, 1.5);
    if (w1 > 0.0) {
        float rho = acos(clamp(dot(d, OS_DAY), -1.0, 1.0));
        float swell = os_window(t, OS_ACT[2] + 0.2, OS_BURST - OS_ACT[2] - 0.5, OS_BURST, 0.3);
        col = mix(col, col + vec3(0.12, 0.11, 0.16), w1 * 0.6);
        col += OS_PALE * exp(-rho * rho / (0.004 + 0.02 * swell)) * swell * 1.4;
        float since = t - OS_BURST;
        if (since > 0.0) {
            float fade = exp(-since * 0.8);
            vec3 side = normalize(cross(OS_DAY, vec3(0.0, 1.0, 0.0)));
            vec3 up = cross(side, OS_DAY);
            float phi = atan(dot(d, up), dot(d, side));
            float rays = pow(max(cos(12.0 * phi), 0.0), 24.0) * smoothstep(0.0, 0.05, rho) * exp(-rho / (0.2 + since * 0.6));
            float ring = exp(-pow((rho - since * 0.8) / 0.05, 2.0));
            col += OS_PALE * (rays * 1.2 + ring * 0.8) * fade;
            col += OS_GOLD * exp(-rho * rho / 0.01) * os_window(t, OS_CROWN - 0.5, 0.5, OS_ACT[3], 1.0) * 0.8;
        }
    }

    // ---- the revival: soul blue, four comets home
    float w2 = os_window(t, OS_ACT[3], 0.8, OS_ACT[4], 1.0);
    if (w2 > 0.0) {
        col = mix(col, col * vec3(0.6, 1.1, 1.3) + OS_SOUL * 0.05, w2 * 0.7);
        float u = clamp((t - OS_SOULS_FROM) / (OS_SOULS_AT - OS_SOULS_FROM), 0.0, 1.1);
        for (int k = 0; k < 4; k++) {
            float a = 1.5707963 * float(k) + 0.7853982;
            vec3 from = normalize(vec3(cos(a), 0.06, sin(a)));
            col += OS_SOULS[k] * os_comet(d, from, vec3(0.0, 1.0, 0.0), u) * 1.6 * w2;
        }
        float arrive = exp(-max(t - OS_SOULS_AT, 0.0) * 1.2) * step(OS_SOULS_AT, t);
        col += OS_PALE * arrive * smoothstep(0.5, 1.0, d.y) * 0.9;
    }

    // ---- the knight: steel, and one sheet of lightning
    float w3 = os_window(t, OS_ACT[4], 0.8, OS_ACT[5], 1.0);
    if (w3 > 0.0) {
        float g = dot(col, vec3(0.3, 0.5, 0.2));
        col = mix(col, vec3(g) * OS_STEEL * 1.6, w3 * 0.55);
        float since = t - OS_BOLT;
        if (since > 0.0) {
            float sheet = exp(-since * 5.0) + 0.5 * exp(-max(since - 0.25, 0.0) * 7.0) * step(0.25, since);
            col += vec3(0.75, 0.80, 1.0) * sheet * pow(os_fbm(d * 4.0 + 3.0), 2.0) * 1.2;
        }
    }

    // ---- the crowns against the server: gold against lavender
    float w4 = os_window(t, OS_ACT[5], 0.8, OS_ACT[6], 1.5);
    if (w4 > 0.0) {
        float side = dot(d, OS_RIGHT);          // + server, - King
        float run = os_window(t, OS_FRONT, OS_CONTACT - OS_FRONT, 1e9, 1.0);
        float line = mix(0.0, -0.75, run);      // the split swings over to his side
        float wobble = 0.05 * sin(d.y * 9.0 + t * 1.3) + 0.03 * sin(dot(d, OS_FWD) * 4.0 + t * 0.2);
        float gold = 1.0 - smoothstep(line - 0.25, line + 0.25, side + wobble);
        float gone = os_window(t, OS_CONTACT, 0.4, 1e9, 1.0);
        gold *= 1.0 - gone;
        vec3 king = col * 0.7 + OS_GOLD * (0.06 + 0.45 * exp(-max(d.y, 0.0) * 4.0)) * (0.7 + 0.6 * os_fbm(d * 5.0 + t * 0.02));
        vec3 them = col * 0.8 + OS_LAVENDER * 0.16;
        col = mix(col, mix(them, king, gold), w4);
        float flash = exp(-max(t - OS_CONTACT, 0.0) * 2.5) * step(OS_CONTACT, t);
        col += OS_PALE * flash * 0.9 * w4;
    }

    // ---- what it cost: the storm bruises
    float w5 = os_window(t, OS_ACT[6], 2.0, OS_GRANT, 0.3);
    col = mix(col, col * vec3(0.75, 0.45, 0.70), w5 * 0.6);

    // ---- the climax: light gathers overhead as she charges, then the sky whites out at her break
    float gather = os_window(t, OS_ACT[7] - 2.0, OS_GRANT - OS_ACT[7] + 2.0, OS_GRANT, 0.2);
    if (gather > 0.0) {
        float up = max(d.y, 0.0);
        float az = atan(d.z, d.x);
        float spokes = pow(max(cos(9.0 * az + t * (1.0 + 4.0 * gather) + 3.0 * up), 0.0), 6.0);
        col += OS_LAVENDER * (pow(up, 6.0) * 1.4 + spokes * smoothstep(0.2, 1.0, up) * 0.5) * gather * gather;
    }
    float since = t - OS_GRANT;
    if (since > 0.0) {
        col = mix(col, vec3(1.0), clamp(exp(-since * 1.1), 0.0, 1.0));
    }

    // ---- the grant: aurora in every colour that can be handed out
    float w6 = os_window(t, OS_GRANT, 1.5, OS_STORY + 4.0, 6.0);
    col += os_aurora(d, t) * w6 * 0.9;
    return col;
}

// Distance (radians, roughly) from the seam, and where along it d is.
vec2 os_seam(vec3 d, float seed) {
    float along = atan(dot(d, OS_FWD), d.y);
    float off = asin(clamp(dot(d, OS_RIGHT), -1.0, 1.0));
    return vec2(abs(off - os_jag(along, seed)), along);
}

// A line of light along the seam: a white core and a lavender bloom. (Unused since 2026-10-12: Kadiri
// read the always-on seam as a lightning bolt, so the sky no longer draws it.)
vec3 os_draw_seam(vec3 col, float dist, float width, float boost) {
    if (width <= 0.0) {
        return col;
    }
    float core = exp(-pow(dist / max(width, 1e-4), 2.0));
    float bloom = exp(-dist / (width * 6.0 + 0.004));
    return col + OS_PALE * core * (1.2 + boost) + OS_LAVENDER * bloom * (0.35 + boost * 0.3);
}

// The rip: tr seconds into the tear (0..OS_TEAR, ping-pong), open 0..1 (the close sets it falling).
vec3 os_rip(vec3 d, float tr, vec3 col, float open) {
    vec2 seam = os_seam(d, 3.0);
    float band = 0.08 + 0.32 * open;
    if (seam.x < band + 0.12) {
        vec2 pl = os_plates(d * 7.0);
        float fall = 1.0 - smoothstep(0.0, band, seam.x + pl.y * 0.12 - open * 0.08);
        fall *= step(pl.y, 0.25 + 0.75 * open);
        // the void behind: near black, its own stars streaking, a violet glow welling up from the seam
        // what is behind the sky: black, a violet glow welling out of the seam, a nebula in it, and
        // its own stars drifting the other way
        vec3 vd = vec3(0.004, 0.0, 0.012);
        vd += vec3(0.55, 0.25, 0.95) * exp(-seam.x / (0.035 + 0.06 * open)) * (0.8 + 0.2 * sin(tr * 1.3));
        vd += vec3(0.25, 0.06, 0.35) * smoothstep(0.45, 0.9, os_fbm(d * 6.0 + vec3(tr * 0.05, 0.0, 0.0)));
        vec3 sp = d * 110.0;
        float star = step(0.982, os_hash(floor(sp + vec3(0.0, -tr * 0.8, 0.0))));
        vd += vec3(0.95, 0.9, 1.0) * star;
        col = mix(col, vd, fall);
        // the plates' torn edges burn white-violet, flickering
        float burn = exp(-pl.x / 0.015) * fall * (0.65 + 0.35 * sin(tr * 2.3 + pl.y * 40.0));
        float rim = exp(-abs(fall - 0.5) * 6.0) * step(0.02, fall) * (1.0 - step(0.98, fall));
        col += vec3(1.0, 0.88, 1.0) * burn * 1.1 + OS_LAVENDER * rim * 0.8;
    }
    return col;
}

// ================================================================ rev 4 (pack v21): the world is made
//
// The made region of the window (from OS_MADE_FROM): the prologue, then three acts of STEPS + 1 held
// looks with an eased run between each pair, then the break. Each act's look is a function of its step
// s (0..8, fractional only in a run), so a hold is a still picture and the plugin moves the sky a step
// each time the players move the story on. An act's step 8 is the next act's step 0.
//
//   prologue  the real noon dies into the void (no seam line: Kadiri read lines as lightning)
//   ground    a violet glow comes up off the horizon as the medallion fills
//   sky       void -> storm -> stars -> aurora: the sky being made
//   land      the land-wake light runs round the horizon, gold, and dawn starts behind it
//   break     light gathers overhead as she charges; a white-out at the break; then aurora in all
//             twelve colours over the storm, which is the sky the tear (v20's rip) opens on

vec3 os_void(vec3 d, float t) {
    vec3 col = mix(vec3(0.035, 0.015, 0.06), vec3(0.008, 0.004, 0.016), smoothstep(-0.1, 0.6, d.y));
    // a nebula drifting, barely there
    float n = os_fbm(d * 3.0 + vec3(0.0, t * 0.01, 0.0));
    col += vec3(0.05, 0.02, 0.08) * smoothstep(0.55, 0.9, n);
    return col;
}

// A hash star field, twinkling: amount 0..1.
vec3 os_starfield(vec3 d, float t, float amount) {
    if (amount <= 0.0 || d.y < -0.05) {
        return vec3(0.0);
    }
    vec3 p = d * 140.0;
    vec3 cell = floor(p);
    vec3 h = os_hash3(cell);
    float on = step(0.982, h.x);
    float dist = length(fract(p) - 0.5 - (h - 0.5) * 0.6);
    float point = exp(-dist * dist / 0.02);
    float twinkle = 0.7 + 0.3 * sin(t * (1.0 + 3.0 * h.y) + h.z * 40.0);
    return vec3(0.9, 0.9, 1.0) * on * point * twinkle * amount * smoothstep(-0.05, 0.15, d.y) * 1.3;
}

// Act I: the ground. p = s / STEPS.
vec3 os_made_ground(vec3 d, float p, float t) {
    vec3 col = os_void(d, t);
    float e = d.y;
    // nothing at step 0, so the act starts on exactly the prologue's void
    float glow = exp(-max(e, 0.0) / (0.04 + 0.22 * p)) * pow(p, 0.8);
    col += vec3(0.45, 0.22, 0.85) * glow * 0.55;
    col += vec3(0.30, 0.15, 0.55) * smoothstep(0.0, -0.3, e) * p * 0.6;
    return col;
}

// The clear night the sky act ends in: deep blue, the ground's violet still on the horizon.
vec3 os_night(vec3 d) {
    vec3 col = mix(vec3(0.06, 0.07, 0.18), vec3(0.012, 0.016, 0.055), smoothstep(-0.05, 0.7, d.y));
    col += vec3(0.30, 0.15, 0.55) * exp(-max(d.y, 0.0) / 0.12) * 0.3;
    return col;
}

// Act II: the sky. s = 0..8.
vec3 os_made_sky(vec3 d, float s, float t) {
    vec3 col = os_made_ground(d, 1.0, t);
    // the storm rolls in over the first steps, and clears from the fourth
    float storm = smoothstep(0.0, 2.5, s) * (1.0 - smoothstep(4.0, 6.0, s));
    vec3 glow = col - os_void(d, t);
    col = mix(col, os_storm(d, t) + glow * 0.5, storm);
    float clear = smoothstep(3.5, 6.0, s);
    col = mix(col, os_night(d), clear);
    col += os_starfield(d, t, smoothstep(3.0, 6.0, s));
    col += os_aurora(d, t) * smoothstep(5.0, 8.0, s) * 0.8;
    return col;
}

// Act III: the land. s = 0..8. The land-wake light comes up round the horizon and dawn starts.
vec3 os_made_land(vec3 d, float s, float t) {
    float p = s / OS_STEPS;
    vec3 col = os_night(d) + os_starfield(d, t, 1.0 - 0.5 * p);
    col += os_aurora(d, t) * 0.8 * (1.0 - 0.5 * p);
    float e = d.y;
    // gold light hugging the horizon, rising as more of the land wakes; a ripple runs round it
    float az = atan(d.z, d.x);
    float band = exp(-abs(e) / (0.03 + 0.12 * p)) * p;
    band *= 0.8 + 0.2 * sin(az * 6.0 - t * 1.5);
    col += vec3(1.0, 0.75, 0.40) * band * 0.7;
    // dawn behind it: the low sky warms and the deep blue lifts
    vec3 dawn = mix(vec3(0.55, 0.32, 0.38), vec3(0.10, 0.14, 0.32), smoothstep(-0.05, 0.6, e));
    col = mix(col, max(col, dawn), smoothstep(0.3, 1.0, p) * 0.6);
    return col;
}

// The break, b seconds in: the gather, the white-out at OS_BREAK_AT, then the twelve-colour aurora.
vec3 os_made_break(vec3 d, float b) {
    float at = OS_BREAK_AT / 20.0;
    vec3 col = os_made_land(d, OS_STEPS, b);
    float gather = os_window(b, 0.0, at, at, 0.2);
    if (gather > 0.0) {
        float up = max(d.y, 0.0);
        float az = atan(d.z, d.x);
        float spokes = pow(max(cos(9.0 * az + b * (1.0 + 4.0 * gather) + 3.0 * up), 0.0), 6.0);
        col += OS_LAVENDER * (pow(up, 6.0) * 1.4 + spokes * smoothstep(0.2, 1.0, up) * 0.5) * gather * gather;
    }
    float since = b - at;
    if (since > 0.0) {
        // after it: the storm she came out of, under every colour that can be handed out
        vec3 after = os_storm(d, OS_STORY - 4.0 + since) + os_aurora(d, OS_STORY - 4.0 + since) * 0.9;
        col = mix(col, after, smoothstep(0.0, 0.3, since));
        col = mix(col, vec3(1.0), clamp(exp(-since * 1.1), 0.0, 1.0));
    }
    return col;
}

// k ticks into the made region.
vec3 os_made(vec3 d, float k) {
    if (k < OS_PRO) {
        float t = k / 20.0;
        vec3 col = os_void(d, t);
        float noon = 1.0 - os_window(t, 0.0, 2.5, 1e9, 1.0);
        if (noon > 0.0) {
            vec3 day = mix(OS_NOON_HOR, OS_NOON_ZEN, smoothstep(0.0, 0.6, d.y));
            col = mix(col, day, noon);
        }
        return col;
    }
    k -= OS_PRO;
    for (int act = 1; act <= 3; act++) {
        if (k < OS_ACT_LEN) {
            float i = floor(k / (OS_HOLD + OS_TRANS));
            float r = k - i * (OS_HOLD + OS_TRANS);
            float s = min(i, OS_STEPS);
            if (i < OS_STEPS && r >= OS_HOLD) {
                float u = clamp((r - OS_HOLD) / OS_TRANS, 0.0, 1.0);
                s = i + u * u * (3.0 - 2.0 * u);
            }
            // the act's own time, for things that move inside a hold
            float t = k / 20.0;
            if (act == 1) {
                return os_made_ground(d, s / OS_STEPS, t);
            }
            if (act == 2) {
                return os_made_sky(d, s, t);
            }
            return os_made_land(d, s, t);
        }
        k -= OS_ACT_LEN;
    }
    return os_made_break(d, k / 20.0);
}

vec3 os_sky(vec3 d, vec4 sky) {
    float ticks = os_ticks(sky);
    if (ticks >= OS_MADE_FROM) {
        return os_made(d, ticks - OS_MADE_FROM);
    }
    float t = ticks / 20.0;
    if (t < OS_STORY) {
        return os_story(d, t);
    }
    float tr = t - OS_STORY;
    if (tr < OS_TEAR) {
        // the story's last sky, still settling, with the rip opening on it over four seconds
        vec3 col = os_story(d, OS_STORY + min(tr, 4.0));
        return os_rip(d, tr, col, os_window(tr, 0.0, 4.0, 1e9, 1.0));
    }
    float tc = tr - OS_TEAR;
    vec3 col = os_storm(d, OS_STORY + tc);
    float open = 1.0 - os_window(tc, 0.0, OS_HEAL - 1.0, 1e9, 1.0);
    col = os_rip(d, tc, col, open);
    // dawn from the east, then noon
    float dawn = os_window(tc, OS_HEAL, 6.0, 1e9, 1.0);
    if (dawn > 0.0) {
        float east = max(dot(normalize(vec3(d.x, 0.0, d.z) + 1e-4), vec3(1.0, 0.0, 0.0)), 0.0);
        vec3 low = mix(vec3(1.0, 0.62, 0.42), vec3(0.95, 0.55, 0.65), 1.0 - east);
        vec3 high = vec3(0.32, 0.45, 0.85);
        vec3 morning = mix(low, high, smoothstep(-0.1, 0.8, d.y));
        morning += vec3(1.0, 0.7, 0.45) * pow(east, 6.0) * exp(-max(d.y, 0.0) * 6.0) * 0.6;
        float noon = os_window(tc, OS_CLOSE - 10.0, 7.0, 1e9, 1.0);
        vec3 day = mix(OS_NOON_HOR, OS_NOON_ZEN, smoothstep(0.0, 0.6, d.y));
        col = mix(col, mix(morning, day, noon), dawn);
    }
    return col;
}
