// Surge's world border (surgepack v22): the edge of the made world as a curtain of light, not the
// vanilla stripes. Used by rendertype_world_border.fsh; previewed by tools/opening-preview.py.
//
// The wall pass is blended additively (BlendFunction OVERLAY), so what is drawn here is light added
// to whatever is behind the wall. Its only clock is the one the game gives the vanilla stripes:
// TextureMat's translation, f = (ms % 3000) / 3000, a sawtooth with a 3 s period. Everything that
// moves is a whole number of turns per period, so the wrap from 1 back to 0 is seamless.
//
// Layers, each a formula of the point on the wall (s along it in blocks, y up it, h = y - eye height)
// and the clock t:
//   curtain   rays  Σ a_k·(½ + ½·sin(f_k·s + φ_k + 2π·m_k·t + 0.8·n(s, y)))^p, the folds of an aurora,
//             their foot swaying with value noise n
//   lattice   a hexagonal net 3 blocks across, faint, its cells lighting one at a time (a hash per cell
//             sets when in the period it glows)
//   sparks    motes rising up the wall, one cell in four, a cell a period
//   band      everything brightest within about 20 blocks of the eye, so the wall reads as a wall
//             wherever the player stands
//
// Colour follows the border's stage, which the game says through ColorModulator: still (blue
// 0x20A0FF) is the opening's violet, growing (0x40FF80) is dawn gold, shrinking (0xFF3030) is a hot
// rose.

float sb_hash(vec2 p) {
    p = fract(p * vec2(127.1, 311.7));
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
}

float sb_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(sb_hash(i), sb_hash(i + vec2(1.0, 0.0)), u.x),
               mix(sb_hash(i + vec2(0.0, 1.0)), sb_hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

/** Distance to the nearest edge of a hexagonal cell (pointy-top, cells `size` across), and its id. */
vec3 sb_hex(vec2 p, float size) {
    vec2 r = vec2(1.0, 1.7320508);
    vec2 hr = r * 0.5;
    p /= size;
    vec2 a = mod(p, r) - hr;
    vec2 b = mod(p - hr, r) - hr;
    vec2 g = dot(a, a) < dot(b, b) ? a : b;
    vec2 id = p - g;
    vec2 ag = abs(g);
    float edge = 0.5 - max(dot(ag, normalize(vec2(1.0, 1.7320508))), ag.x);
    return vec3(edge * size, id);
}

/** The light the wall adds at a point: rgb, and how much (0..1). */
vec4 sb_wall(vec3 wallPos, float t, float eyeY, vec3 stage) {
    const float TAU = 6.28318531;
    float s = wallPos.x + wallPos.z;
    float y = wallPos.y;
    float h = y - eyeY;

    // which stage, by the nearest of the three vanilla colours
    float dStill = distance(stage, vec3(0.125, 0.627, 1.0));
    float dGrow = distance(stage, vec3(0.251, 1.0, 0.502));
    float dShrink = distance(stage, vec3(1.0, 0.188, 0.188));
    vec3 deep;
    vec3 bright;
    float energy;
    if (dGrow < dStill && dGrow < dShrink) {
        deep = vec3(0.95, 0.55, 0.22);
        bright = vec3(1.0, 0.92, 0.70);
        energy = 1.15;
    } else if (dShrink < dStill) {
        deep = vec3(1.0, 0.22, 0.35);
        bright = vec3(1.0, 0.78, 0.82);
        energy = 1.4;
    } else {
        deep = vec3(0.42, 0.25, 0.95);
        bright = vec3(0.86, 0.80, 1.0);
        energy = 1.0;
    }

    // the curtain: four sets of folds, each turning a whole number of times a period
    float sway = sb_noise(vec2(s * 0.06, y * 0.025 - t * 2.0)) * 0.8 + sb_noise(vec2(s * 0.15 + 9.0, y * 0.05)) * 0.4;
    float curtain = 0.0;
    curtain += 0.55 * pow(0.5 + 0.5 * sin(0.91 * s + 0.3 + TAU * t + 2.0 * sway), 6.0);
    curtain += 0.40 * pow(0.5 + 0.5 * sin(0.37 * s + 1.7 - TAU * t + 1.4 * sway), 4.0);
    curtain += 0.30 * pow(0.5 + 0.5 * sin(1.73 * s + 4.1 + 2.0 * TAU * t + 3.0 * sway), 10.0);
    curtain += 0.25 * pow(0.5 + 0.5 * sin(0.21 * s + 2.9 + TAU * t + 0.8 * sway), 3.0);
    // the folds fade up and down the wall in long slow bands
    float bands = 0.55 + 0.45 * sb_noise(vec2(s * 0.03 + 3.0, y * 0.04 - t));
    curtain *= bands;

    // the lattice: a faint net, a cell now and then lighting up as its time comes round
    // (was a hex lattice; now drifting wisps: domain-warped noise, its mid-level contour a soft filament)
    vec2 wp = vec2(s * 0.12, y * 0.08 - t);
    vec2 warp = vec2(sb_noise(wp + vec2(3.1, 0.0)), sb_noise(wp * 1.3 + vec2(0.0, 7.7))) - 0.5;
    float wn = sb_noise(wp * 1.7 + warp * 2.2) * 0.65 + sb_noise(wp * 3.9 - warp) * 0.35;
    float net = exp(-pow((wn - 0.5) / 0.035, 2.0)) * 0.18;
    float cell = smoothstep(0.6, 0.9, wn) * 0.15 * (0.5 + 0.5 * sin(TAU * t + wn * 6.0));

    // sparks rising: in a lattice of cells half a block wide, one in four holds a spark, one cell a period
    vec2 sp = vec2(s * 2.0, y * 0.5 - t);
    vec2 si = floor(sp);
    vec2 sf = fract(sp) - 0.5;
    float has = step(0.75, sb_hash(si));
    float spark = has * exp(-dot(sf * vec2(1.0, 3.0), sf * vec2(1.0, 3.0)) / 0.01);

    // brightest near the eye's height, so it is a wall wherever you stand
    float band = 0.35 + 0.65 * exp(-pow(h / 22.0, 2.0));

    float light = (curtain * 0.6 + net + cell * 0.9 + spark * 0.7) * band * energy;
    vec3 col = mix(deep, bright, clamp(curtain * 0.5 + cell + spark, 0.0, 1.0));
    return vec4(col, clamp(light, 0.0, 1.0));
}
