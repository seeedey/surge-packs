#version 150

uniform sampler2D Sampler0;

#moj_import <multiversion.glsl>
in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

in vec3 glCornerTex1;
in vec3 glCornerTex2;
in vec3 glCornerTex3;
in vec3 glCornerTex4;

in vec3 uvCornerTex1;
in vec3 uvCornerTex2;
in vec3 uvCornerTex3;
in vec3 uvCornerTex4;

in vec4 sPos;
in float is3D;
in float fontID;
in float floatIsShadow;
in vec4 baseColor;
in vec4 lightColor;
in float isMap;

out vec4 fragColor;

struct Text {
	float id;
	vec4 glPos;
    int glVertex;

    float alphaRead;
	vec4 color;
	bool isShadow;

	vec2 uv;
	vec2 uvMin;
	vec2 uvMax;
	vec2 uvCenter;

	vec2 size;
	vec2 pos;
	vec2 localPos;
	vec2 charPos;
	ivec2 pixelPos;
};
Text text;

#moj_import <utils.glsl>
#moj_import <effects/text.glsl>
#moj_import <effects/font.glsl>
#moj_import <imports/text.glsl>
#moj_import <imports/font.glsl>

void main() {
	text.isShadow = floatIsShadow > 0.5;
	text.id = fontID;

	text.color = baseColor;
    text.alphaRead = baseColor.a;

	vec2 glCornerUV1 = glCornerTex1.xy / glCornerTex1.z;
	vec2 glCornerUV2 = glCornerTex2.xy / glCornerTex2.z;
	vec2 glCornerUV3 = glCornerTex3.xy / glCornerTex3.z;
	vec2 glCornerUV4 = glCornerTex4.xy / glCornerTex4.z;

	vec2 uvCornerUV1 = uvCornerTex1.xy / uvCornerTex1.z;
	vec2 uvCornerUV2 = uvCornerTex2.xy / uvCornerTex2.z;
	vec2 uvCornerUV3 = uvCornerTex3.xy / uvCornerTex3.z;
	vec2 uvCornerUV4 = uvCornerTex4.xy / uvCornerTex4.z;

	vec2 glMin = min(glCornerUV1,min(glCornerUV2,min(glCornerUV3,glCornerUV4)));
	vec2 glMax = max(glCornerUV1,max(glCornerUV2,max(glCornerUV3,glCornerUV4)));
	vec2 glSize = glMax - glMin;

	vec2 uvMin = min(uvCornerUV1,min(uvCornerUV2,min(uvCornerUV3,uvCornerUV4)));
	vec2 uvMax = max(uvCornerUV1,max(uvCornerUV2,max(uvCornerUV3,uvCornerUV4)));
	vec2 uvSize = uvMax - uvMin;

	text.uvMin = uvMin;
	text.uvMax = uvMax;
	text.uvCenter = uvMin + 0.25 * uvSize;

	text.localPos = ((sPos.xy - glMin) / glSize);
	text.localPos.y = 1.0 - text.localPos.y;

	text.pos = sPos.xy * 256.0;
	text.uv = texCoord0;

	text.charPos = 0.5 * (glMin + glMax) * uvSize * 256.0 / glSize;

	text.pixelPos = ivec2(int(floor((text.uv.yx + 0.00004 - text.uvMin.yx) * 256.0)));

#moj_import <configs/text.glsl>
#moj_import <configs/font.glsl>

	vec4 textureSample = texture(Sampler0, text.uv);

	vec4 color = textureSample * text.color * ColorModulator * lightColor;

	if(isMap > 0.5) color = texture(Sampler0, texCoord0) * baseColor * lightColor * ColorModulator;
    if(color.a < 1 / 255.) discard;
    fragColor = applyFog(color, 1);
}