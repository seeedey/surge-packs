MODEL_SHADER(1) {
    return;
}