PARTICLE_SHADER(1) {
    vec4 sn = simpleNoise(
        worldDirection,
        vec3(1.00, 0.35, 0.75),
        vec3(1.00, 0.75, 0.90),
        18.0,
        0.02
    );

    float n = noise(worldDirection * 128.0 + vec3(GameTime * 0.02));

    sn.rgb = mix(sn.rgb * 0.7, sn.rgb * 2.0, n);

    fragColor = sn;
    return;
}