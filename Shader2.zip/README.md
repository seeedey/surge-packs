# Hyper's Shader Template

### A quick and full-featured template for particles, models, text, and font.

Combines [Ult-Effects](https://github.com/Dystortedd/Ult-Effects) and [SkyboxTemplate](https://github.com/Dragoncraft000/SkyboxTemplate)

Supports 1.21.4-1.21.11
Title support doesn't work on 1.21.6+

# Credits
Credits to Dystortedd for [Ult-Effects](https://github.com/Dystortedd/Ult-Effects), Dragoncraft000 for [Ult-Effects](https://github.com/Dystortedd/Ult-Effects) 1.21.6+ port and [SkyboxTemplate](https://github.com/Dragoncraft000/SkyboxTemplate)
